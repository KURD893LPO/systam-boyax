---
name: Generated API client DOM types
description: TypeScript library configuration needed by the Orval-generated browser client.
---

The generated React API client uses `Headers.entries()`. Its TypeScript configuration must include `dom.iterable` alongside `dom`; otherwise typecheck reports `Property 'entries' does not exist on type 'Headers'`.

**Why:** The generated code depends on iterable DOM declarations that are not included by the base DOM library alone.

**How to apply:** Preserve `dom.iterable` in `lib/api-client-react/tsconfig.json` when changing TypeScript libs or regenerating the client.