import { createInsertSchema } from "drizzle-zod";
import {
  boolean,
  integer,
  numeric,
  pgEnum,
  pgTable,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

export const shopCurrencyEnum = pgEnum("shop_currency", ["USD", "IQD"]);
export const shopCurrencyTransactionKindEnum = pgEnum("shop_currency_transaction_kind", [
  "exchange",
  "deposit",
  "withdrawal",
  "expense",
]);

export const productsTable = pgTable("shop_products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  price: numeric("price", { precision: 14, scale: 2 }).notNull(),
  currency: shopCurrencyEnum("currency").notNull(),
  category: text("category").notNull().default("کالا"),
  unit: text("unit").notNull().default("دانە"),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const customersTable = pgTable("shop_customers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  phone: text("phone"),
  notes: text("notes"),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const staffTable = pgTable("shop_staff", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  phone: text("phone"),
  role: text("role"),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const salesTable = pgTable("shop_sales", {
  id: serial("id").primaryKey(),
  customerId: integer("customer_id")
    .notNull()
    .references(() => customersTable.id),
  staffId: integer("staff_id").references(() => staffTable.id, {
    onDelete: "set null",
  }),
  note: text("note"),
  totalUsd: numeric("total_usd", { precision: 14, scale: 2 }).notNull().default("0"),
  totalIqd: numeric("total_iqd", { precision: 14, scale: 2 }).notNull().default("0"),
  paidUsd: numeric("paid_usd", { precision: 14, scale: 2 }).notNull().default("0"),
  paidIqd: numeric("paid_iqd", { precision: 14, scale: 2 }).notNull().default("0"),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const saleItemsTable = pgTable("shop_sale_items", {
  id: serial("id").primaryKey(),
  saleId: integer("sale_id")
    .notNull()
    .references(() => salesTable.id, { onDelete: "cascade" }),
  // Keep a product snapshot so removing or renaming a catalog item never
  // changes the customer's purchase history.
  productId: integer("product_id").notNull(),
  productName: text("product_name").notNull(),
  quantity: integer("quantity").notNull(),
  unitPrice: numeric("unit_price", { precision: 14, scale: 2 }).notNull(),
  currency: shopCurrencyEnum("currency").notNull(),
  total: numeric("total", { precision: 14, scale: 2 }).notNull(),
});

export const debtPaymentsTable = pgTable("shop_debt_payments", {
  id: serial("id").primaryKey(),
  customerId: integer("customer_id")
    .notNull()
    .references(() => customersTable.id),
  amount: numeric("amount", { precision: 14, scale: 2 }).notNull(),
  currency: shopCurrencyEnum("currency").notNull(),
  note: text("note"),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const currencyTransactionsTable = pgTable("shop_currency_transactions", {
  id: serial("id").primaryKey(),
  kind: shopCurrencyTransactionKindEnum("kind").notNull(),
  currency: shopCurrencyEnum("currency").notNull(),
  amount: numeric("amount", { precision: 14, scale: 2 }).notNull(),
  targetCurrency: shopCurrencyEnum("target_currency"),
  targetAmount: numeric("target_amount", { precision: 14, scale: 2 }),
  exchangeRate: numeric("exchange_rate", { precision: 18, scale: 8 }),
  category: text("category"),
  note: text("note"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertProductSchema = createInsertSchema(productsTable).omit({
  id: true,
  createdAt: true,
});
export const insertCustomerSchema = createInsertSchema(customersTable).omit({
  id: true,
  createdAt: true,
});
export const insertStaffSchema = createInsertSchema(staffTable).omit({
  id: true,
  createdAt: true,
});
export const insertSaleSchema = createInsertSchema(salesTable).omit({
  id: true,
  createdAt: true,
});
export const insertSaleItemSchema = createInsertSchema(saleItemsTable).omit({
  id: true,
});
export const insertDebtPaymentSchema = createInsertSchema(debtPaymentsTable).omit({
  id: true,
  createdAt: true,
});
export const insertCurrencyTransactionSchema = createInsertSchema(currencyTransactionsTable).omit({
  id: true,
  createdAt: true,
});

export type Currency = "USD" | "IQD";
export type Product = typeof productsTable.$inferSelect;
export type Customer = typeof customersTable.$inferSelect;
export type Staff = typeof staffTable.$inferSelect;
export type Sale = typeof salesTable.$inferSelect;
export type SaleItem = typeof saleItemsTable.$inferSelect;
export type DebtPayment = typeof debtPaymentsTable.$inferSelect;
export type CurrencyTransaction = typeof currencyTransactionsTable.$inferSelect;