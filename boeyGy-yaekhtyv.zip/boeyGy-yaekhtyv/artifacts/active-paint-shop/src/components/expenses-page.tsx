import { useState } from 'react';
import type { CSSProperties, FormEvent, ReactNode } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { Banknote, CircleDollarSign, Plus, RefreshCw, X } from 'lucide-react';
import {
  getGetCurrencyAccountQueryKey,
  getListExpensesQueryKey,
  useCreateExpense,
  useGetCurrencyAccount,
  useListExpenses,
} from '@workspace/api-client-react';
import type { Currency, ExpenseInput } from '@workspace/api-client-react';
import { Link } from 'wouter';

const categoryOptions = ['کرێ', 'کارەبا و ئاو', 'مووچە', 'گواستنەوە', 'کڕینی پێداویستی', 'چاککردنەوە', 'خەرجی گشتی'];
const otherCategoryValue = '__other__';

function formatAmount(value: number) {
  return new Intl.NumberFormat('ar-IQ', {
    maximumFractionDigits: value % 1 === 0 ? 0 : 2,
    minimumFractionDigits: value % 1 === 0 ? 0 : 2,
  }).format(value);
}

function Money({ amount, currency }: { amount: number; currency: Currency }) {
  return <span className="money"><span>{formatAmount(amount)}</span><span className="currency">{currency}</span></span>;
}

function formatDate(value: string) {
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) return '—';
  return new Intl.DateTimeFormat('ar-IQ', { dateStyle: 'medium', timeStyle: 'short' }).format(parsed);
}

function Modal({ onClose, children }: { onClose: () => void; children: ReactNode }) {
  return <div className="modal-backdrop" onMouseDown={event => {
    if (event.target === event.currentTarget) onClose();
  }}>
    <section className="modal" role="dialog" aria-modal="true" aria-labelledby="expense-modal-title">
      <div className="modal-head">
        <div>
          <h2 id="expense-modal-title" className="modal-title">تۆمارکردنی خەرجی دوکان</h2>
          <p className="modal-copy">بڕەکە لە باڵانسی هەمان دراو کەم دەکرێتەوە.</p>
        </div>
        <button className="icon-button" onClick={onClose} aria-label="داخستن"><X /></button>
      </div>
      {children}
    </section>
  </div>;
}

function Field({ label, children, span = false }: { label: string; children: ReactNode; span?: boolean }) {
  return <div className={`field${span ? ' span-2' : ''}`}><label>{label}</label>{children}</div>;
}

export function ExpensesPage() {
  const expensesQuery = useListExpenses();
  const accountQuery = useGetCurrencyAccount();
  const createExpense = useCreateExpense();
  const queryClient = useQueryClient();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currency, setCurrency] = useState<Currency>('USD');
  const [category, setCategory] = useState(categoryOptions[0]);
  const [customCategory, setCustomCategory] = useState('');
  const [amount, setAmount] = useState('');
  const [note, setNote] = useState('');
  const [error, setError] = useState('');

  const expenses = expensesQuery.data ?? [];
  const account = accountQuery.data;
  const amountValue = Number(amount);
  const balance = currency === 'USD' ? account?.balanceUsd ?? 0 : account?.balanceIqd ?? 0;
  const now = new Date();
  const monthExpenses = expenses.filter(expense => {
    const date = new Date(expense.createdAt);
    return date.getFullYear() === now.getFullYear() && date.getMonth() === now.getMonth();
  });
  const monthUsd = monthExpenses.filter(expense => expense.currency === 'USD').reduce((total, expense) => total + expense.amount, 0);
  const monthIqd = monthExpenses.filter(expense => expense.currency === 'IQD').reduce((total, expense) => total + expense.amount, 0);

  function openForm() {
    setCurrency('USD');
    setCategory(categoryOptions[0]);
    setCustomCategory('');
    setAmount('');
    setNote('');
    setError('');
    setIsModalOpen(true);
  }

  function submit(event: FormEvent) {
    event.preventDefault();
    setError('');
    const roundedAmount = Math.round(amountValue * 100) / 100;
    const finalCategory = category === otherCategoryValue ? customCategory.trim() : category;
    if (!Number.isFinite(amountValue) || amountValue <= 0 || roundedAmount <= 0) {
      setError('بڕێکی دروست و زیاتر لە سفر بنووسە.');
      return;
    }
    if (!finalCategory) {
      setError('جۆری خەرجی دیاری بکە.');
      return;
    }
    if (amountValue > balance + 0.001) {
      setError('باڵانسی بەردەست بۆ ئەم خەرجییە بەس نییە.');
      return;
    }

    const data: ExpenseInput = {
      category: finalCategory,
      currency,
      amount: amountValue,
      note: note.trim() || null,
    };
    createExpense.mutate({ data }, {
      onSuccess: () => {
        setIsModalOpen(false);
        void queryClient.invalidateQueries({ queryKey: getListExpensesQueryKey() });
        void queryClient.invalidateQueries({ queryKey: getGetCurrencyAccountQueryKey() });
      },
      onError: () => setError('تۆمارکردن سەرکەوتوو نەبوو؛ باڵانس و زانیارییەکان بپشکنە.'),
    });
  }

  if (expensesQuery.isLoading || accountQuery.isLoading) {
    return <>
      <div className="page-heading"><div><p className="eyebrow">بۆیاغی ئەکتیڤ / بەڕێوەبردن</p><h1 className="page-title">خەرجی دوکان</h1><p className="page-desc">خەرجییەکان بە پۆل تۆمار بکە و بە جیا چاودێرییان بکە.</p></div></div>
      <div className="loading-grid"><div className="skeleton skeleton-card" /><div className="skeleton skeleton-card" /></div>
    </>;
  }

  if (expensesQuery.isError || accountQuery.isError || !account) {
    return <>
      <div className="page-heading"><div><p className="eyebrow">بۆیاغی ئەکتیڤ / بەڕێوەبردن</p><h1 className="page-title">خەرجی دوکان</h1><p className="page-desc">خەرجییەکان بە پۆل تۆمار بکە و بە جیا چاودێرییان بکە.</p></div></div>
      <div className="surface state-box" role="alert">
        <div className="state-icon"><RefreshCw /></div><h2 className="state-title">زانیاریی خەرجی بارنەکرا</h2>
        <p className="state-copy">تکایە جارێکی تر هەوڵ بدەرەوە.</p>
        <button className="button button-quiet" onClick={() => {
          void expensesQuery.refetch();
          void accountQuery.refetch();
        }}><RefreshCw /> دووبارە هەوڵدان</button>
      </div>
    </>;
  }

  return <>
    <div className="page-heading">
      <div>
        <p className="eyebrow">بۆیاغی ئەکتیڤ <span style={{ opacity: .45, padding: '0 4px' }}>/</span> بەڕێوەبردن</p>
        <h1 className="page-title">خەرجی دوکان</h1>
        <p className="page-desc">خەرجییەکان بە پۆل تۆمار بکە؛ هەر خەرجی لە باڵانسی دراوی خۆی کەم دەکرێتەوە.</p>
      </div>
      <button className="button button-primary" onClick={openForm} data-testid="button-new-expense"><Plus /> تۆمارکردنی خەرجی</button>
    </div>

    <section className="stat-grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(210px, 1fr))' }}>
      <article className="surface stat-card" style={{ '--stat-color': '#a76a2f', '--stat-wash': 'rgba(187,112,69,.11)' } as CSSProperties}>
        <div className="stat-top"><span>خەرجی ئەم مانگە · USD</span><span className="stat-icon"><Banknote /></span></div>
        <div className="stat-value"><Money amount={monthUsd} currency="USD" /></div>
        <div className="stat-foot">تەنها خەرجییەکانی دۆلار</div>
      </article>
      <article className="surface stat-card" style={{ '--stat-color': '#a76a2f', '--stat-wash': 'rgba(187,112,69,.11)' } as CSSProperties}>
        <div className="stat-top"><span>خەرجی ئەم مانگە · IQD</span><span className="stat-icon"><Banknote /></span></div>
        <div className="stat-value"><Money amount={monthIqd} currency="IQD" /></div>
        <div className="stat-foot">تەنها خەرجییەکانی دینار</div>
      </article>
      <article className="surface stat-card" style={{ '--stat-color': '#1e6b54', '--stat-wash': 'rgba(31,105,81,.1)' } as CSSProperties}>
        <div className="stat-top"><span>باڵانسی بەردەست · USD</span><span className="stat-icon"><CircleDollarSign /></span></div>
        <div className="stat-value"><Money amount={account.balanceUsd} currency="USD" /></div>
        <div className="stat-foot">دوای کەمکردنەوەی خەرجییەکان</div>
      </article>
      <article className="surface stat-card" style={{ '--stat-color': '#1e6b54', '--stat-wash': 'rgba(31,105,81,.1)' } as CSSProperties}>
        <div className="stat-top"><span>باڵانسی بەردەست · IQD</span><span className="stat-icon"><CircleDollarSign /></span></div>
        <div className="stat-value"><Money amount={account.balanceIqd} currency="IQD" /></div>
        <div className="stat-foot">دوای کەمکردنەوەی خەرجییەکان</div>
      </article>
    </section>

    <section className="surface section-card" style={{ marginTop: 16 }}>
      <div className="section-head">
        <div><h2 className="section-title">مێژووی خەرجییەکان</h2><p className="section-sub">خەرجییەکان لە باڵانسی دراوی خۆیان کەم دەکرێنەوە.</p></div>
        <span className="pill pill-muted">{formatAmount(expenses.length)} تۆمار</span>
      </div>
      {expenses.length ? <div className="table-wrap"><table>
        <thead><tr><th>پۆلی خەرجی</th><th>بڕ</th><th>بەروار</th><th>تێبینی</th></tr></thead>
        <tbody>{expenses.map(expense => <tr key={expense.id} data-testid={`row-expense-${expense.id}`}>
          <td className="primary-cell">{expense.category}</td>
          <td><span style={{ color: '#8a5546' }}>− <Money amount={expense.amount} currency={expense.currency} /></span></td>
          <td>{formatDate(expense.createdAt)}</td>
          <td>{expense.note || '—'}</td>
        </tr>)}</tbody>
      </table></div> : <div className="state-box">
        <div className="state-icon"><Banknote /></div>
        <h2 className="state-title">هێشتا خەرجییەک تۆمار نەکراوە</h2>
        <p className="state-copy">خەرجییەک تۆمار بکە بۆ ئەوەی لێرە بە جیا و بە پۆل پیشان بدرێت.</p>
        <button className="button button-primary" onClick={openForm}><Plus /> تۆمارکردنی یەکەم خەرجی</button>
      </div>}
    </section>

    {isModalOpen && <Modal onClose={() => setIsModalOpen(false)}>
      <form onSubmit={submit}>
        <div className="form-grid">
          <Field label="پۆلی خەرجی">
            <select className="select" value={category} onChange={event => setCategory(event.target.value)} data-testid="select-expense-category">
              {categoryOptions.map(option => <option key={option} value={option}>{option}</option>)}
              <option value={otherCategoryValue}>پۆلێکی تر</option>
            </select>
          </Field>
          <Field label="دراو">
            <select className="select" value={currency} onChange={event => setCurrency(event.target.value as Currency)} data-testid="select-expense-currency">
              <option value="USD">دۆلاری ئەمریکی · USD</option><option value="IQD">دیناری عێراقی · IQD</option>
            </select>
          </Field>
          {category === otherCategoryValue && <Field label="ناوی پۆلی خەرجی" span>
            <input className="input" value={customCategory} onChange={event => setCustomCategory(event.target.value)} required data-testid="input-expense-custom-category" />
          </Field>}
          <Field label="بڕ" span>
            <input className="input" type="number" min="0.01" step="0.01" dir="ltr" value={amount} onChange={event => setAmount(event.target.value)} required data-testid="input-expense-amount" />
            <div className="secondary-cell" style={{ marginTop: 5 }}>باڵانسی بەردەست: <Money amount={balance} currency={currency} /></div>
          </Field>
          <Field label="تێبینی (ئارەزوومەندانە)" span>
            <input className="input" value={note} onChange={event => setNote(event.target.value)} data-testid="input-expense-note" />
          </Field>
        </div>
        {error && <p role="alert" style={{ color: '#a34436', fontSize: 11 }}>{error}</p>}
        <div className="modal-actions">
          <button className="button button-primary" type="submit" disabled={createExpense.isPending}>
            {createExpense.isPending ? 'تۆمار دەکرێت...' : 'پاشەکەوتکردنی خەرجی'}
          </button>
          <button className="button button-quiet" type="button" onClick={() => setIsModalOpen(false)}>پاشگەزبوونەوە</button>
        </div>
      </form>
    </Modal>}
  </>;
}