import { useState } from 'react';
import type { CSSProperties, FormEvent, ReactNode } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import {
  ArrowDownToLine,
  ArrowLeftRight,
  ArrowUpFromLine,
  CircleDollarSign,
  Plus,
  RefreshCw,
  X,
} from 'lucide-react';
import {
  getGetCurrencyAccountQueryKey,
  useCreateCurrencyTransaction,
  useGetCurrencyAccount,
  useGetCurrencyRate,
} from '@workspace/api-client-react';
import type { Currency, CurrencyTransaction, CurrencyTransactionInput } from '@workspace/api-client-react';

type TransactionKind = 'exchange' | 'deposit' | 'withdrawal';

function formatAmount(value: number, digits = value % 1 === 0 ? 0 : 2) {
  return new Intl.NumberFormat('ar-IQ', {
    maximumFractionDigits: digits,
    minimumFractionDigits: digits,
  }).format(value);
}

function Money({ amount, currency }: { amount: number; currency: Currency }) {
  return <span className="money"><span>{formatAmount(amount)}</span><span className="currency">{currency}</span></span>;
}

function Modal({ title, subtitle, onClose, children }: {
  title: string;
  subtitle: string;
  onClose: () => void;
  children: ReactNode;
}) {
  return <div className="modal-backdrop" onMouseDown={event => {
    if (event.target === event.currentTarget) onClose();
  }}>
    <section className="modal" role="dialog" aria-modal="true" aria-labelledby="currency-modal-title">
      <div className="modal-head">
        <div>
          <h2 id="currency-modal-title" className="modal-title">{title}</h2>
          <p className="modal-copy">{subtitle}</p>
        </div>
        <button className="icon-button" onClick={onClose} aria-label="داخستن"><X /></button>
      </div>
      {children}
    </section>
  </div>;
}

function Field({ label, children, span = false }: { label: string; children: ReactNode; span?: boolean }) {
  return <div className={`field${span ? ' span-2' : ''}`}><label>{label}</label>{children}</div>;
}

function transactionKindLabel(kind: CurrencyTransaction['kind']) {
  if (kind === 'exchange') return 'ئاڵوگۆڕی دراو';
  if (kind === 'deposit') return 'زیادکردنی باڵانس';
  if (kind === 'withdrawal') return 'کەمکردنەوەی باڵانس';
  return 'خەرجی دوکان';
}

function transactionDate(value: string) {
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) return '—';
  return new Intl.DateTimeFormat('ar-IQ', { dateStyle: 'medium', timeStyle: 'short' }).format(parsed);
}

export function CurrencyAccountPage() {
  const accountQuery = useGetCurrencyAccount();
  const rateQuery = useGetCurrencyRate();
  const createTransaction = useCreateCurrencyTransaction();
  const queryClient = useQueryClient();
  const [mode, setMode] = useState<TransactionKind | null>(null);
  const [currency, setCurrency] = useState<Currency>('USD');
  const [amount, setAmount] = useState('');
  const [exchangeRate, setExchangeRate] = useState('');
  const [note, setNote] = useState('');
  const [error, setError] = useState('');

  const account = accountQuery.data;
  const rate = rateQuery.data;
  const balances = { USD: account?.balanceUsd ?? 0, IQD: account?.balanceIqd ?? 0 };
  const fromAmount = Number(amount);
  const rateValue = Number(exchangeRate);
  const targetCurrency: Currency = currency === 'USD' ? 'IQD' : 'USD';
  const targetAmount = mode === 'exchange' && fromAmount > 0 && rateValue > 0
    ? Math.round((currency === 'USD' ? fromAmount * rateValue : fromAmount / rateValue) * 100) / 100
    : null;

  function openTransaction(nextMode: TransactionKind) {
    setMode(nextMode);
    setCurrency('USD');
    setAmount('');
    setExchangeRate(rate ? String(rate.rate) : '');
    setNote('');
    setError('');
  }

  function submit(event: FormEvent) {
    event.preventDefault();
    setError('');
    if (!mode) return;
    const normalizedAmount = Math.round(fromAmount * 100) / 100;
    if (!Number.isFinite(fromAmount) || fromAmount <= 0 || normalizedAmount <= 0) {
      setError('بڕێکی دروست و زیاتر لە سفر بنووسە.');
      return;
    }
    if (mode !== 'deposit' && fromAmount > balances[currency] + 0.001) {
      setError('باڵانسی بەردەست بۆ ئەم مامەڵەیە بەس نییە.');
      return;
    }
    if (mode === 'exchange' && (!Number.isFinite(rateValue) || rateValue <= 0)) {
      setError('نرخی دۆلار بە دینار بنووسە.');
      return;
    }

    const data: CurrencyTransactionInput = {
      kind: mode,
      currency,
      amount: fromAmount,
      note: note.trim() || null,
      ...(mode === 'exchange' ? { exchangeRate: rateValue } : {}),
    };
    createTransaction.mutate({ data }, {
      onSuccess: () => {
        setMode(null);
        void queryClient.invalidateQueries({ queryKey: getGetCurrencyAccountQueryKey() });
      },
      onError: () => setError('تۆمارکردنی مامەڵە سەرکەوتوو نەبوو؛ باڵانس و بڕەکە بپشکنە.'),
    });
  }

  if (accountQuery.isLoading) {
    return <>
      <div className="page-heading"><div><p className="eyebrow">بۆیاغی ئەکتیڤ / بەڕێوەبردن</p><h1 className="page-title">حیسابی دراو</h1><p className="page-desc">باڵانسی دۆلار و دینار و مامەڵەکانی ئاڵوگۆڕ.</p></div></div>
      <div className="loading-grid"><div className="skeleton skeleton-card" /><div className="skeleton skeleton-card" /></div>
    </>;
  }

  if (accountQuery.isError || !account) {
    return <>
      <div className="page-heading"><div><p className="eyebrow">بۆیاغی ئەکتیڤ / بەڕێوەبردن</p><h1 className="page-title">حیسابی دراو</h1><p className="page-desc">باڵانسی دۆلار و دینار و مامەڵەکانی ئاڵوگۆڕ.</p></div></div>
      <div className="surface state-box" role="alert">
        <div className="state-icon"><RefreshCw /></div><h2 className="state-title">زانیاریی حیسابی دراو بارنەکرا</h2>
        <p className="state-copy">تکایە جارێکی تر هەوڵ بدەرەوە.</p>
        <button className="button button-quiet" onClick={() => void accountQuery.refetch()}><RefreshCw /> دووبارە هەوڵدان</button>
      </div>
    </>;
  }

  const activeModeLabel = mode === 'exchange'
    ? 'ئاڵوگۆڕی دراو'
    : mode === 'deposit'
      ? 'زیادکردنی باڵانس'
      : 'کەمکردنەوەی باڵانس';

  return <>
    <div className="page-heading">
      <div>
        <p className="eyebrow">بۆیاغی ئەکتیڤ <span style={{ opacity: .45, padding: '0 4px' }}>/</span> بەڕێوەبردن</p>
        <h1 className="page-title">حیسابی دۆلار و دینار</h1>
        <p className="page-desc">باڵانسی USD و IQD و مامەڵەکانی ئاڵوگۆڕ بە جیا لە فرۆشتنی دوکان بەڕێوەببە.</p>
      </div>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
        <button className="button button-primary" onClick={() => openTransaction('exchange')}><ArrowLeftRight /> ئاڵوگۆڕ</button>
        <button className="button button-quiet" onClick={() => openTransaction('deposit')}><ArrowDownToLine /> زیادکردنی باڵانس</button>
        <button className="button button-quiet" onClick={() => openTransaction('withdrawal')}><ArrowUpFromLine /> کەمکردنەوە</button>
      </div>
    </div>

    <section className="stat-grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))' }}>
      <article className="surface stat-card" style={{ '--stat-color': '#1e6b54', '--stat-wash': 'rgba(31,105,81,.1)' } as CSSProperties}>
        <div className="stat-top"><span>باڵانسی دۆلار</span><span className="stat-icon"><CircleDollarSign /></span></div>
        <div className="stat-value"><Money amount={account.balanceUsd} currency="USD" /></div>
        <div className="stat-foot">بڕی بەردەستی حیسابی USD</div>
      </article>
      <article className="surface stat-card" style={{ '--stat-color': '#a76a2f', '--stat-wash': 'rgba(187,112,69,.11)' } as CSSProperties}>
        <div className="stat-top"><span>باڵانسی دینار</span><span className="stat-icon"><CircleDollarSign /></span></div>
        <div className="stat-value"><Money amount={account.balanceIqd} currency="IQD" /></div>
        <div className="stat-foot">بڕی بەردەستی حیسابی IQD</div>
      </article>
    </section>

    <section className="surface section-card" style={{ marginTop: 16 }}>
      <div className="section-head">
        <div><h2 className="section-title">نرخی ڕێنمایی USD/IQD</h2><p className="section-sub">نرخی گشتی ئۆنلاین؛ لەوانەیە لە نرخی بازاڕی عێراق جیاواز بێت.</p></div>
        <button className="icon-button" onClick={() => void rateQuery.refetch()} aria-label="نوێکردنەوەی نرخ" title="نوێکردنەوەی نرخ"><RefreshCw /></button>
      </div>
      {rate ? <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 16, flexWrap: 'wrap' }}>
        <div style={{ fontSize: 20, fontWeight: 800, color: '#244a3d' }}>
          ١ USD = {formatAmount(rate.rate, 4)} IQD
        </div>
        <div className="secondary-cell" style={{ textAlign: 'right' }}>
          نوێکراوەتەوە: {transactionDate(rate.updatedAt)} · دواتر: {transactionDate(rate.nextUpdateAt)}
          <br />
          سەرچاوە: <a href="https://www.exchangerate-api.com" target="_blank" rel="noreferrer">ExchangeRate-API</a>
        </div>
      </div> : <div className="notice" role="status" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 12 }}>
        <span>{rateQuery.isLoading ? 'نرخی ئۆنلاین بار دەکرێت...' : 'نرخی ئۆنلاین بەردەست نییە؛ دەتوانیت نرخ بە دەستی بنووسیت.'}</span>
        {rateQuery.isError && <button className="link-subtle" onClick={() => void rateQuery.refetch()}>دووبارە هەوڵدان</button>}
      </div>}
      <p className="secondary-cell" style={{ marginTop: 10 }}>سەرچاوەکە ڕۆژانە نوێ دەبێتەوە؛ نرخی گشتییە و نرخێکی کڕین و فرۆشتنی ناوخۆیی نییە.</p>
    </section>

    <section className="surface section-card" style={{ marginTop: 16 }}>
      <div className="section-head">
        <div><h2 className="section-title">مێژووی حیسابی دراو</h2><p className="section-sub">زیادکردن، کەمکردنەوە و ئاڵوگۆڕەکان</p></div>
        <span className="pill pill-muted">{formatAmount(account.transactions.length)} مامەڵە</span>
      </div>
      {account.transactions.length ? <div className="table-wrap"><table>
        <thead><tr><th>جۆری مامەڵە</th><th>بڕ</th><th>نرخ</th><th>بەروار</th><th>تێبینی</th></tr></thead>
        <tbody>{account.transactions.map(transaction => <tr key={transaction.id} data-testid={`row-currency-transaction-${transaction.id}`}>
          <td><div className="primary-cell">{transactionKindLabel(transaction.kind)}</div>{transaction.category && <div className="secondary-cell">{transaction.category}</div>}</td>
          <td>{transaction.kind === 'exchange' && transaction.targetCurrency && transaction.targetAmount !== undefined
            ? <span dir="ltr" style={{ display: 'inline-flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}><Money amount={transaction.amount} currency={transaction.currency} /><span aria-hidden="true">→</span><Money amount={transaction.targetAmount} currency={transaction.targetCurrency} /></span>
            : <span style={{ color: transaction.kind === 'deposit' ? '#1e6b54' : '#8a5546' }}>{transaction.kind === 'deposit' ? '+' : '−'} <Money amount={transaction.amount} currency={transaction.currency} /></span>}
          </td>
          <td>{transaction.exchangeRate ? `1 USD = ${formatAmount(transaction.exchangeRate, 4)} IQD` : '—'}</td>
          <td>{transactionDate(transaction.createdAt)}</td>
          <td>{transaction.note || '—'}</td>
        </tr>)}</tbody>
      </table></div> : <div className="state-box">
        <div className="state-icon"><CircleDollarSign /></div>
        <h2 className="state-title">هێشتا مامەڵەیەک تۆمار نەکراوە</h2>
        <p className="state-copy">بۆ دەستپێکردن، باڵانسی سەرەتایی زیاد بکە یان ئاڵوگۆڕێکی نوێ تۆمار بکە.</p>
        <button className="button button-primary" onClick={() => openTransaction('deposit')}><Plus /> زیادکردنی باڵانسی سەرەتایی</button>
      </div>}
    </section>

    {mode && <Modal title={activeModeLabel} subtitle="مامەڵەکە بە جیا لە فرۆشتنی دوکان تۆمار دەکرێت." onClose={() => setMode(null)}>
      <form onSubmit={submit}>
        <div className="form-grid">
          <Field label="دراوی بڕ">
            <select className="select" value={currency} onChange={event => setCurrency(event.target.value as Currency)} data-testid="select-currency-transaction-currency">
              <option value="USD">دۆلاری ئەمریکی · USD</option><option value="IQD">دیناری عێراقی · IQD</option>
            </select>
          </Field>
          <Field label={mode === 'exchange' ? 'بڕی دراوی دەستپێک' : 'بڕ'}>
            <input className="input" type="number" min="0.01" step="0.01" dir="ltr" value={amount} onChange={event => setAmount(event.target.value)} required data-testid="input-currency-transaction-amount" />
            {mode !== 'deposit' && <div className="secondary-cell" style={{ marginTop: 5 }}>باڵانسی بەردەست: <Money amount={balances[currency]} currency={currency} /></div>}
          </Field>
          {mode === 'exchange' && <>
            <Field label="نرخی ئاڵوگۆڕ · 1 USD بە IQD" span>
              <div style={{ display: 'flex', gap: 8 }}>
                <input className="input" type="number" min="0.000001" step="any" dir="ltr" value={exchangeRate} onChange={event => setExchangeRate(event.target.value)} required data-testid="input-currency-exchange-rate" />
                {rate && <button className="button button-quiet button-small" type="button" onClick={() => setExchangeRate(String(rate.rate))}>نرخی ئۆنلاین</button>}
              </div>
            </Field>
            {targetAmount !== null && <div className="notice span-2" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 10 }}>
              <span>بڕی وەرگیراو</span><Money amount={targetAmount} currency={targetCurrency} />
            </div>}
          </>}
          <Field label="تێبینی (ئارەزوومەندانە)" span>
            <input className="input" value={note} onChange={event => setNote(event.target.value)} data-testid="input-currency-transaction-note" />
          </Field>
        </div>
        {error && <p role="alert" style={{ color: '#a34436', fontSize: 11 }}>{error}</p>}
        <div className="modal-actions">
          <button className="button button-primary" type="submit" disabled={createTransaction.isPending}>
            {createTransaction.isPending ? 'تۆمار دەکرێت...' : 'پاشەکەوتکردنی مامەڵە'}
          </button>
          <button className="button button-quiet" type="button" onClick={() => setMode(null)}>پاشگەزبوونەوە</button>
        </div>
      </form>
    </Modal>}
  </>;
}