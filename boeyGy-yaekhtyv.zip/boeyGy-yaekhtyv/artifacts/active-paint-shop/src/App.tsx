import { useState } from 'react';
import type { CSSProperties, FormEvent, ReactNode } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import {
  ArrowLeft, Banknote, Boxes, ChevronLeft, CircleDollarSign, ContactRound, CreditCard, FileText,
  LayoutDashboard, Package, Paintbrush, Plus, ReceiptText, RefreshCw, Search,
  ShoppingBag, Trash2, Users, WalletCards, X, Pencil,
} from 'lucide-react';
import {
  getGetShopOverviewQueryKey, getGetCustomerLedgerQueryKey, getListCustomersQueryKey,
  getListDebtsQueryKey, getListProductsQueryKey, getListSalesQueryKey, getListStaffQueryKey,
  useCreateCustomer, useCreateDebtPayment, useCreateProduct, useCreateSale, useCreateStaff,
  useDeleteCustomer, useDeleteDebtPayment, useDeleteProduct, useDeleteSale, useDeleteStaff,
  useGetCustomerLedger, useGetShopOverview, useListCustomers, useListDebts, useListProducts,
  useListSales, useListStaff, useUpdateCustomer, useUpdateDebtPayment, useUpdateProduct,
  useUpdateSale, useUpdateStaff,
} from '@workspace/api-client-react';
import type {
  Customer, CustomerInput, CustomerUpdate, Currency, CustomerDebt, DebtPayment, Product,
  ProductInput, ProductUpdate, Sale, SaleInput, Staff, StaffInput, StaffUpdate,
} from '@workspace/api-client-react';
import { Link, Route, Switch, useLocation, useParams, Router as WouterRouter } from 'wouter';
import { ErrorBoundary } from '@/components/error-boundary';
import { CurrencyAccountPage } from '@/components/currency-account-page';
import { ExpensesPage } from '@/components/expenses-page';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';

const queryClient = new QueryClient({
  defaultOptions: { queries: { refetchOnWindowFocus: false, retry: 1 } },
});

const navItems = [
  { href: '/', label: 'پوختەی دوکان', icon: LayoutDashboard },
  { href: '/sales', label: 'فرۆشتنەکان', icon: ReceiptText },
  { href: '/products', label: 'کاڵاکان', icon: Boxes },
  { href: '/customers', label: 'کڕیارەکان', icon: Users },
  { href: '/debts', label: 'قەرزەکان', icon: WalletCards },
  { href: '/currency', label: 'حیسابی دراو', icon: CircleDollarSign },
  { href: '/expenses', label: 'خەرجی دوکان', icon: Banknote },
  { href: '/staff', label: 'کارمەندان', icon: ContactRound },
];

function number(value: number, digits = 0) {
  return new Intl.NumberFormat('ar-IQ', { maximumFractionDigits: digits, minimumFractionDigits: digits }).format(value);
}
const kurdishDays = ['یەکشەممە', 'دووشەممە', 'سێشەممە', 'چوارشەممە', 'پێنجشەممە', 'هەینی', 'شەممە'];
const kurdishMonths = ['کانوونی دووەم', 'شوبات', 'ئازار', 'نیسان', 'ئایار', 'حوزەیران', 'تەممووز', 'ئاب', 'ئەیلوول', 'تشرینی یەکەم', 'تشرینی دووەم', 'کانوونی یەکەم'];
function kurdishDate(value: Date, weekday = false) {
  const prefix = weekday ? `${kurdishDays[value.getDay()]}، ` : '';
  return `${prefix}${number(value.getDate())}ی ${kurdishMonths[value.getMonth()]} ${number(value.getFullYear())}`;
}
function date(value?: string | null) {
  if (!value) return '—';
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) return '—';
  return kurdishDate(parsed);
}
function time(value?: string | null) {
  if (!value) return '—';
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) return '—';
  const clock = new Intl.NumberFormat('ar-IQ', { minimumIntegerDigits: 2, useGrouping: false });
  return `${kurdishDate(parsed)}، ${clock.format(parsed.getHours())}:${clock.format(parsed.getMinutes())}`;
}
function Money({ amount, currency }: { amount: number; currency: Currency }) {
  return <span className="money"><span>{number(amount, amount % 1 === 0 ? 0 : 2)}</span><span className="currency">{currency}</span></span>;
}
function CurrencyPair({ usd, iqd }: { usd: number; iqd: number }) {
  return <span style={{ display: 'inline-flex', gap: 9, flexWrap: 'wrap' }}><Money amount={usd} currency="USD" /><Money amount={iqd} currency="IQD" /></span>;
}
function Header({ title, subtitle, action }: { title: string; subtitle: string; action?: ReactNode }) {
  return <div className="page-heading">
    <div><p className="eyebrow">بۆیاغی ئەکتیڤ <span style={{ opacity: .45, padding: '0 4px' }}>/</span> بەڕێوەبردن</p><h1 className="page-title">{title}</h1><p className="page-desc">{subtitle}</p></div>
    {action}
  </div>;
}
function Button({ children, kind = 'primary', small = false, onClick, type = 'button', disabled, testId }: {
  children: ReactNode; kind?: 'primary' | 'quiet' | 'danger'; small?: boolean; onClick?: () => void;
  type?: 'button' | 'submit'; disabled?: boolean; testId?: string;
}) {
  return <button type={type} onClick={onClick} disabled={disabled} data-testid={testId} className={`button button-${kind}${small ? ' button-small' : ''}`} style={disabled ? { opacity: .55, cursor: 'not-allowed' } : undefined}>{children}</button>;
}
function LoadingState({ rows = 4 }: { rows?: number }) {
  return <div aria-label="بارکردن" aria-busy="true"><div className="loading-grid">{Array.from({ length: rows }, (_, i) => <div className="skeleton skeleton-card" key={i} />)}</div><div className="surface" style={{ padding: 14, marginTop: 16 }}>{Array.from({ length: 4 }, (_, i) => <div className="skeleton skeleton-line" key={i} />)}</div></div>;
}
function ErrorState({ retry }: { retry: () => void }) {
  return <div className="surface state-box" role="alert"><div className="state-icon"><RefreshCw /></div><h2 className="state-title">پەیوەندی بە زانیارییەکانەوە نەکرا</h2><p className="state-copy">تکایە جارێکی تر هەوڵ بدەرەوە.</p><Button kind="quiet" onClick={retry}><RefreshCw /> دووبارە هەوڵدان</Button></div>;
}
function EmptyState({ icon: Icon = Package, title, detail, action }: { icon?: typeof Package; title: string; detail: string; action?: ReactNode }) {
  return <div className="state-box"><div className="state-icon"><Icon /></div><h2 className="state-title">{title}</h2><p className="state-copy">{detail}</p>{action}</div>;
}
function SearchBox({ value, onChange, placeholder }: { value: string; onChange: (v: string) => void; placeholder: string }) {
  return <div className="search-box"><Search /><input className="input" value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder} aria-label={placeholder} data-testid="input-search" /></div>;
}
function ArchivedFilter({ checked, onChange, label }: { checked: boolean; onChange: (checked: boolean) => void; label: string }) {
  return <label style={{ display: 'inline-flex', alignItems: 'center', gap: 7, fontSize: 11, fontWeight: 700, color: '#66796e', whiteSpace: 'nowrap' }}>
    <input type="checkbox" checked={checked} onChange={e => onChange(e.target.checked)} />{label}
  </label>;
}
function Modal({ title, subtitle, onClose, children }: { title: string; subtitle: string; onClose: () => void; children: ReactNode }) {
  return <div className="modal-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}>
    <section className="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title">
      <div className="modal-head"><div><h2 id="modal-title" className="modal-title">{title}</h2><p className="modal-copy">{subtitle}</p></div><button className="icon-button" onClick={onClose} aria-label="داخستن" data-testid="button-modal-close"><X /></button></div>
      {children}
    </section>
  </div>;
}
function Field({ label, children, span = false }: { label: string; children: ReactNode; span?: boolean }) {
  return <div className={`field${span ? ' span-2' : ''}`}><label>{label}</label>{children}</div>;
}
function AppShell() {
  const [location] = useLocation();
  const section = navItems.find(n => n.href === location)?.label ?? (location.startsWith('/customers/') ? 'وردەکاری کڕیار' : 'بەڕێوەبردن');
  return <div className="app-shell" dir="rtl">
    <aside className="sidebar">
      <Link href="/" className="brand" aria-label="بۆیاغی ئەکتیڤ، سەرەتا">
        <div className="brand-mark"><Paintbrush size={20} /></div><div><h2 className="brand-title">بۆیاغی ئەکتیڤ</h2><div className="brand-sub">بۆیاغ و کەرەستە</div></div>
      </Link>
      <div className="nav-caption">بەڕێوەبردنی دوکان</div>
      <nav className="nav-stack" aria-label="بەڕێوەبردن">
        {navItems.map(({ href, label, icon: Icon }) => <Link key={href} href={href} className={`nav-link${location === href || (href === '/customers' && location.startsWith('/customers/')) ? ' active' : ''}`} data-testid={`link-nav-${href === '/' ? 'home' : href.slice(1)}`}><Icon />{label}</Link>)}
      </nav>
      <div className="sidebar-foot"><div className="shop-status"><span className="status-dot" /> سیستەم چالاکە</div><div className="sidebar-hint">زانیارییەکان بە شێوەی ڕاستەوخۆ نوێ دەبنەوە</div></div>
    </aside>
    <div className="main-area">
      <header className="topbar">
        <div className="crumb"><span>بۆیاغی ئەکتیڤ</span><ChevronLeft size={13} /><strong style={{ color: '#385b4c' }}>{section}</strong></div>
        <div className="top-date">{kurdishDate(new Date(), true)}</div>
        <div className="user-chip"><div className="user-dot">ب</div><div><div className="user-name">بەڕێوەبەری دوکان</div><div className="user-role">بۆیاغی ئەکتیڤ</div></div></div>
      </header>
      <main className="page-wrap"><Switch>
        <Route path="/" component={DashboardPage} />
        <Route path="/products" component={ProductsPage} />
        <Route path="/customers/:id" component={CustomerLedgerPage} />
        <Route path="/customers" component={CustomersPage} />
        <Route path="/debts" component={DebtsPage} />
        <Route path="/currency" component={CurrencyAccountPage} />
        <Route path="/expenses" component={ExpensesPage} />
        <Route path="/staff" component={StaffPage} />
        <Route path="/sales" component={SalesPage} />
        <Route component={NotFound} />
      </Switch></main>
      <nav className="mobile-nav" aria-label="بەڕێوەبردن لە مۆبایل">
        {navItems.map(({ href, label, icon: Icon }) => <Link key={href} href={href} className={`mobile-link${location === href || (href === '/customers' && location.startsWith('/customers/')) ? ' active' : ''}`} data-testid={`mobile-link-${href === '/' ? 'home' : href.slice(1)}`}><Icon />{label}</Link>)}
      </nav>
    </div>
  </div>;
}
function DashboardPage() {
  const query = useGetShopOverview();
  const overview = query.data;
  if (query.isLoading) return <><Header title="پوختەی دوکان" subtitle="ڕوانینێکی خێرا لە بارودۆخی ئەمڕۆ." /><LoadingState /></>;
  if (query.isError || !overview) return <><Header title="پوختەی دوکان" subtitle="ڕوانینێکی خێرا لە بارودۆخی ئەمڕۆ." /><ErrorState retry={() => query.refetch()} /></>;
  const stats = [
    { label: 'فرۆشتنی ئەمڕۆ', value: number(overview.salesToday), icon: ShoppingBag, foot: 'ژمارەی مامەڵەکان', color: '#1e6b54', wash: 'rgba(31,105,81,.1)' },
    { label: 'کاڵاکانی تۆمارکراو', value: number(overview.productCount), icon: Boxes, foot: 'لە کاتەلۆگی دوکان', color: '#bb7045', wash: 'rgba(187,112,69,.11)' },
    { label: 'کڕیارەکان', value: number(overview.customerCount), icon: Users, foot: 'کڕیارانی تۆمارکراو', color: '#677e4d', wash: 'rgba(103,126,77,.11)' },
    { label: 'کارمەندان', value: number(overview.staffCount), icon: ContactRound, foot: 'تیمی دوکان', color: '#4e7a81', wash: 'rgba(78,122,129,.11)' },
  ];
  return <>
    <Header title="پوختەی دوکان" subtitle="ئەمڕۆ، هەموو شتێک لە یەک شوێنە." action={<Link href="/sales" className="button button-primary" data-testid="button-new-sale"><Plus /> تۆمارکردنی فرۆشتن</Link>} />
    <section className="stat-grid">
      {stats.map(({ label, value, icon: Icon, foot, color, wash }) => <article className="surface stat-card" key={label} style={{ '--stat-color': color, '--stat-wash': wash } as CSSProperties}>
        <div className="stat-top"><span>{label}</span><span className="stat-icon"><Icon /></span></div><div className="stat-value">{value}</div><div className="stat-foot">{foot}</div>
      </article>)}
    </section>
    <div className="dashboard-lower">
      <section className="surface section-card">
        <div className="section-head"><div><h2 className="section-title">دوایین فرۆشتنەکان</h2><p className="section-sub">تۆمارە نوێیەکانی فرۆشتن</p></div><Link href="/sales" className="link-subtle">هەموو فرۆشتنەکان <ArrowLeft size={13} style={{ verticalAlign: 'middle' }} /></Link></div>
        {overview.recentSales.length ? <SalesTable sales={overview.recentSales} /> : <EmptyState icon={ReceiptText} title="هێشتا فرۆشتنێک تۆمار نەکراوە" detail="کاتێک فرۆشتنێک تۆمار بکەیت، لێرە دەردەکەوێت." />}
      </section>
      <div style={{ display: 'grid', gap: 14, alignContent: 'start' }}>
        <section className="surface section-card" style={{ background: '#f3ead7' }}>
          <div className="section-head"><div><h2 className="section-title">داهاتی ئەمڕۆ</h2><p className="section-sub">بە جیاوازی دراوەکان</p></div><span className="stat-icon" style={{ '--stat-color': '#a76a2f', '--stat-wash': '#ebdcc0' } as CSSProperties}><CircleDollarSign /></span></div>
          <div style={{ display: 'grid', gap: 12 }}><div><div className="secondary-cell">دۆلاری ئەمریکی</div><div style={{ marginTop: 5 }}><Money amount={overview.salesTodayUsd} currency="USD" /></div></div><div><div className="secondary-cell">دیناری عێراقی</div><div style={{ marginTop: 5 }}><Money amount={overview.salesTodayIqd} currency="IQD" /></div></div></div>
        </section>
        <section className="surface section-card">
          <div className="section-head"><div><h2 className="section-title">قەرزی ماوە</h2><p className="section-sub">کۆی قەرزی کڕیاران</p></div><span className="stat-icon" style={{ '--stat-color': '#b15f42', '--stat-wash': '#f5e7dc' } as CSSProperties}><CreditCard /></span></div>
          <div style={{ display: 'grid', gap: 11 }}><Money amount={overview.debtUsd} currency="USD" /><Money amount={overview.debtIqd} currency="IQD" /></div>
          <Link className="link-subtle" href="/debts" style={{ display: 'inline-block', marginTop: 16 }}>بینینی قەرزەکان <ArrowLeft size={13} style={{ verticalAlign: 'middle' }} /></Link>
        </section>
      </div>
    </div>
  </>;
}
function SalesTable({ sales, showActions = false }: { sales: Sale[]; showActions?: boolean }) {
  return <div className="table-wrap"><table><thead><tr><th>کڕیار</th><th>بەروار</th><th>کۆی فرۆشتن</th><th>کاڵا</th>{showActions && <th>بار و کردار</th>}</tr></thead><tbody>
    {sales.slice(0, showActions ? undefined : 8).map(s => <tr key={s.id} data-testid={`row-sale-${s.id}`}><td><div className="primary-cell">{s.customerName}</div><div className="secondary-cell">{s.staffName || 'کارمەند دیاری نەکراوە'}</div></td><td>{time(s.createdAt)}</td><td><CurrencyPair usd={s.totalUsd} iqd={s.totalIqd} /></td><td>{number(s.items.length)}</td>{showActions && <td><div style={{ display: 'flex', alignItems: 'center', gap: 5 }}><span className={`pill${s.active ? '' : ' pill-muted'}`}>{s.active ? 'چالاک' : 'هەڵوەشێنراوە'}</span><SaleStatusAction sale={s} /></div></td>}</tr>)}
  </tbody></table></div>;
}

function ProductsPage() {
  const query = useListProducts();
  const cache = useQueryClient();
  const remove = useDeleteProduct();
  const restore = useUpdateProduct();
  const [search, setSearch] = useState('');
  const [showArchived, setShowArchived] = useState(false);
  const [editing, setEditing] = useState<Product | null | undefined>(undefined);
  const products = query.data ?? [];
  const filtered = products.filter(p => (showArchived || p.active) && `${p.name} ${p.category} ${p.unit}`.toLowerCase().includes(search.toLowerCase()));
  const refresh = () => Promise.all([cache.invalidateQueries({ queryKey: getListProductsQueryKey() }), cache.invalidateQueries({ queryKey: getGetShopOverviewQueryKey() })]);
  const handleToggle = (product: Product) => {
    if (product.active) {
      if (window.confirm(`ئایا دڵنیایت لە لابردنی «${product.name}»؟ مێژووی فرۆشتنی دەمێنێتەوە.`)) {
        remove.mutate({ id: product.id }, { onSuccess: refresh });
      }
    } else {
      restore.mutate({ id: product.id, data: { active: true } }, { onSuccess: refresh });
    }
  };
  return <>
    <Header title="کاتەلۆگی کاڵاکان" subtitle="نرخ و وردەکاریی کاڵاکانی دوکان بەڕێوەببە." action={<Button onClick={() => setEditing(null)}><Plus /> زیادکردنی کاڵا</Button>} />
    {query.isLoading ? <LoadingState /> : query.isError ? <ErrorState retry={() => query.refetch()} /> : <>
      <div className="toolbar"><SearchBox value={search} onChange={setSearch} placeholder="گەڕان بە ناو، جۆر یان یەکە..." /><span className="pill pill-muted">{number(products.filter(p => p.active).length)} کاڵای چالاک</span><ArchivedFilter checked={showArchived} onChange={setShowArchived} label="پیشاندانی کاڵای لابراو" /></div>
      <section className="surface section-card">
        {filtered.length ? <div className="table-wrap"><table><thead><tr><th>ناوی کاڵا</th><th>جۆر</th><th>یەکە</th><th>نرخ</th><th>بار</th><th>کردار</th></tr></thead><tbody>
          {filtered.map(p => <tr key={p.id} data-testid={`row-product-${p.id}`}><td className="primary-cell">{p.name}</td><td>{p.category || 'جۆر تۆمار نەکراوە'}</td><td>{p.unit || '—'}</td><td><Money amount={p.price} currency={p.currency} /></td><td><span className={`pill${p.active ? '' : ' pill-muted'}`}><span className="status-dot" style={{ width: 6, height: 6, boxShadow: 'none', background: p.active ? '#679875' : '#9a9d94' }} />{p.active ? 'چالاک' : 'لابراو'}</span></td><td><div style={{ display: 'flex', gap: 3 }}><button className="icon-button" aria-label={`دەستکاری ${p.name}`} onClick={() => setEditing(p)} data-testid={`button-edit-product-${p.id}`}><Pencil /></button><button className="icon-button" aria-label={p.active ? `لابردنی ${p.name}` : `گەڕاندنەوەی ${p.name}`} title={p.active ? 'لابردن' : 'گەڕاندنەوە'} onClick={() => handleToggle(p)} disabled={remove.isPending || restore.isPending} data-testid={`${p.active ? 'button-delete' : 'button-restore'}-product-${p.id}`}>{p.active ? <Trash2 /> : <RefreshCw />}</button></div></td></tr>)}
        </tbody></table></div> : <EmptyState icon={Boxes} title={search ? 'هیچ کاڵایەک نەدۆزرایەوە' : showArchived ? 'کاڵایەک نییە' : 'کاتەلۆگی چالاک بەتاڵە'} detail={search ? 'وشەیەکی تر بگەڕێ.' : 'کاڵا تۆمار بکە یان کاڵاکانی لابراو پیشان بدە.'} action={!search && !showArchived && <Button onClick={() => setEditing(null)}><Plus /> زیادکردنی کاڵا</Button>} />}
      </section>
    </>}
    {editing !== undefined && <ProductModal item={editing} onClose={() => setEditing(undefined)} onSaved={() => { setEditing(undefined); void refresh(); }} />}
  </>;
}
function ProductModal({ item, onClose, onSaved }: { item: Product | null; onClose: () => void; onSaved: () => void }) {
  const create = useCreateProduct(); const update = useUpdateProduct();
  const [name, setName] = useState(item?.name ?? '');
  const [price, setPrice] = useState(item ? String(item.price) : '');
  const [currency, setCurrency] = useState<Currency>(item?.currency ?? 'USD');
  const [category, setCategory] = useState(item?.category ?? '');
  const [unit, setUnit] = useState(item?.unit ?? '');
  const [active, setActive] = useState(item?.active ?? true);
  const [error, setError] = useState('');
  const pending = create.isPending || update.isPending;
  function submit(e: FormEvent) {
    e.preventDefault(); setError('');
    const value = Number(price);
    if (!name.trim() || !Number.isFinite(value) || value < 0) { setError('ناو و نرخێکی دروست پێویستە.'); return; }
    if (item) {
      const data: ProductUpdate = { name: name.trim(), price: value, currency, category, unit, active };
      update.mutate({ id: item.id, data }, { onSuccess: onSaved, onError: () => setError('تۆمارکردن سەرکەوتوو نەبوو. جارێکی تر هەوڵ بدەرەوە.') });
    } else {
      const data: ProductInput = { name: name.trim(), price: value, currency, category, unit };
      create.mutate({ data }, { onSuccess: onSaved, onError: () => setError('زیادکردنی کاڵا سەرکەوتوو نەبوو.') });
    }
  }
  return <Modal title={item ? 'دەستکاریکردنی کاڵا' : 'کاڵای نوێ'} subtitle="زانیارییەکان بە دراو و یەکەی ڕوون تۆمار بکە." onClose={onClose}>
    <form onSubmit={submit}><div className="form-grid">
      <Field label="ناوی کاڵا" span><input className="input" autoFocus value={name} onChange={e => setName(e.target.value)} required data-testid="input-product-name" /></Field>
      <Field label="نرخ"><input className="input" type="number" min="0" step="any" value={price} onChange={e => setPrice(e.target.value)} required dir="ltr" data-testid="input-product-price" /></Field>
      <Field label="دراو"><select className="select" value={currency} onChange={e => setCurrency(e.target.value as Currency)} data-testid="select-product-currency"><option value="USD">دۆلاری ئەمریکی · USD</option><option value="IQD">دیناری عێراقی · IQD</option></select></Field>
      <Field label="جۆر"><input className="input" value={category} onChange={e => setCategory(e.target.value)} placeholder="جۆری کاڵا" data-testid="input-product-category" /></Field>
      <Field label="یەکە"><input className="input" value={unit} onChange={e => setUnit(e.target.value)} placeholder="دانە، لیتەر..." data-testid="input-product-unit" /></Field>
      {item && <label className="span-2" style={{ display: 'flex', alignItems: 'center', gap: 9, fontSize: 11, fontWeight: 700, color: '#566c61' }}><input type="checkbox" checked={active} onChange={e => setActive(e.target.checked)} /> کاڵاکە چالاکە</label>}
    </div>{error && <p role="alert" style={{ color: '#a34436', fontSize: 11 }}>{error}</p>}<div className="modal-actions"><Button type="submit" disabled={pending}>{pending ? 'تۆمار دەکرێت...' : item ? 'پاشەکەوتکردن' : 'زیادکردنی کاڵا'}</Button><Button kind="quiet" onClick={onClose}>پاشگەزبوونەوە</Button></div></form>
  </Modal>;
}

function CustomersPage() {
  const query = useListCustomers(); const cache = useQueryClient(); const remove = useDeleteCustomer(); const restore = useUpdateCustomer();
  const [search, setSearch] = useState(''); const [showArchived, setShowArchived] = useState(false); const [editing, setEditing] = useState<Customer | null | undefined>(undefined);
  const customers = query.data ?? []; const filtered = customers.filter(c => (showArchived || c.active) && `${c.name} ${c.phone ?? ''}`.toLowerCase().includes(search.toLowerCase()));
  const refresh = () => Promise.all([cache.invalidateQueries({ queryKey: getListCustomersQueryKey() }), cache.invalidateQueries({ queryKey: getGetShopOverviewQueryKey() }), cache.invalidateQueries({ queryKey: getListDebtsQueryKey() })]);
  const toggleActive = (customer: Customer) => {
    if (customer.active) {
      if (window.confirm(`ئایا دڵنیایت لە لابردنی «${customer.name}»؟ مێژووی فرۆشتن و قەرزەکانی دەمێنێتەوە.`)) {
        remove.mutate({ id: customer.id }, { onSuccess: refresh, onError: () => window.alert('لابردنی کڕیار سەرکەوتوو نەبوو.') });
      }
    } else {
      restore.mutate({ id: customer.id, data: { active: true } }, { onSuccess: refresh, onError: () => window.alert('گەڕاندنەوەی کڕیار سەرکەوتوو نەبوو.') });
    }
  };
  return <>
    <Header title="کڕیارەکان" subtitle="پەیوەندی و باڵانسی هەر کڕیارێک لەگەڵ خۆیدا بپارێزە." action={<Button onClick={() => setEditing(null)}><Plus /> تۆمارکردنی کڕیار</Button>} />
    {query.isLoading ? <LoadingState /> : query.isError ? <ErrorState retry={() => query.refetch()} /> : <>
      <div className="toolbar"><SearchBox value={search} onChange={setSearch} placeholder="گەڕان بە ناو یان ژمارەی مۆبایل..." /><span className="pill pill-muted">{number(customers.filter(c => c.active).length)} کڕیاری چالاک</span><ArchivedFilter checked={showArchived} onChange={setShowArchived} label="پیشاندانی کڕیارانی لابراو" /></div>
      <section className="surface section-card">{filtered.length ? <div className="table-wrap"><table><thead><tr><th>کڕیار</th><th>بار</th><th>ژمارەی تەلەفۆن</th><th>قەرز</th><th>تۆمارکراوە لە</th><th>وردەکاری</th><th>کردار</th></tr></thead><tbody>
        {filtered.map(c => <tr key={c.id} data-testid={`row-customer-${c.id}`}><td className="primary-cell">{c.name}</td><td><span className={`pill${c.active ? '' : ' pill-muted'}`}>{c.active ? 'چالاک' : 'لابراو'}</span></td><td>{c.phone || '—'}</td><td><CurrencyPair usd={c.debtUsd} iqd={c.debtIqd} /></td><td>{date(c.createdAt)}</td><td><Link className="link-subtle" href={`/customers/${c.id}`} data-testid={`link-customer-ledger-${c.id}`}>دفترچە <ArrowLeft size={12} style={{ verticalAlign: 'middle' }} /></Link></td><td><div style={{ display: 'flex', gap: 3 }}><button className="icon-button" aria-label={`دەستکاری ${c.name}`} onClick={() => setEditing(c)} data-testid={`button-edit-customer-${c.id}`}><Pencil /></button><button className="icon-button" aria-label={c.active ? `لابردنی ${c.name}` : `گەڕاندنەوەی ${c.name}`} title={c.active ? 'لابردن' : 'گەڕاندنەوە'} onClick={() => toggleActive(c)} disabled={remove.isPending || restore.isPending} data-testid={`${c.active ? 'button-delete' : 'button-restore'}-customer-${c.id}`}>{c.active ? <Trash2 /> : <RefreshCw />}</button></div></td></tr>)}
      </tbody></table></div> : <EmptyState icon={Users} title={search ? 'کڕیار نەدۆزرایەوە' : showArchived ? 'کڕیارێک نییە' : 'کڕیاری چالاک نییە'} detail={search ? 'گەڕانەکەت بگۆڕە.' : showArchived ? 'کڕیار تۆمار بکە بۆ بەڕێوەبردنی فرۆشتن و قەرز.' : 'کڕیارانی لابراو پیشان بدە یان کڕیارێکی نوێ تۆمار بکە.'} action={!search && <Button onClick={() => setEditing(null)}><Plus /> تۆمارکردنی کڕیار</Button>} />}</section>
    </>}
    {editing !== undefined && <CustomerModal item={editing} onClose={() => setEditing(undefined)} onSaved={() => { setEditing(undefined); void refresh(); }} />}
  </>;
}
function CustomerModal({ item, onClose, onSaved }: { item: Customer | null; onClose: () => void; onSaved: () => void }) {
  const create = useCreateCustomer(); const update = useUpdateCustomer(); const cache = useQueryClient(); const [name, setName] = useState(item?.name ?? ''); const [phone, setPhone] = useState(item?.phone ?? ''); const [notes, setNotes] = useState(item?.notes ?? ''); const [error, setError] = useState('');
  const pending = create.isPending || update.isPending;
  function submit(e: FormEvent) { e.preventDefault(); setError(''); if (!name.trim()) { setError('ناوی کڕیار پێویستە.'); return; }
    if (item) { const data: CustomerUpdate = { name: name.trim(), phone, notes }; update.mutate({ id: item.id, data }, { onSuccess: () => { void cache.invalidateQueries({ queryKey: getGetCustomerLedgerQueryKey(item.id) }); onSaved(); }, onError: () => setError('نوێکردنەوە سەرکەوتوو نەبوو.') }); }
    else { const data: CustomerInput = { name: name.trim(), phone, notes }; create.mutate({ data }, { onSuccess: onSaved, onError: () => setError('تۆمارکردنی کڕیار سەرکەوتوو نەبوو.') }); }
  }
  return <Modal title={item ? 'دەستکاریکردنی کڕیار' : 'کڕیاری نوێ'} subtitle="زانیاریی بنەڕەتی کڕیار تۆمار بکە." onClose={onClose}><form onSubmit={submit}><div className="form-grid">
    <Field label="ناوی کڕیار" span><input className="input" autoFocus value={name} onChange={e => setName(e.target.value)} required data-testid="input-customer-name" /></Field>
    <Field label="ژمارەی مۆبایل" span><input className="input" dir="ltr" value={phone} onChange={e => setPhone(e.target.value)} data-testid="input-customer-phone" /></Field>
    <Field label="تێبینی" span><textarea className="textarea" value={notes} onChange={e => setNotes(e.target.value)} data-testid="input-customer-notes" /></Field>
  </div>{error && <p role="alert" style={{ color: '#a34436', fontSize: 11 }}>{error}</p>}<div className="modal-actions"><Button type="submit" disabled={pending}>{pending ? 'تۆمار دەکرێت...' : item ? 'پاشەکەوتکردن' : 'تۆمارکردنی کڕیار'}</Button><Button kind="quiet" onClick={onClose}>پاشگەزبوونەوە</Button></div></form></Modal>;
}

function CustomerLedgerPage() {
  const params = useParams<{ id?: string }>(); const customerId = Number(params.id); const valid = Number.isFinite(customerId) && customerId > 0;
  const query = useGetCustomerLedger(valid ? customerId : 0, { query: { enabled: valid, queryKey: getGetCustomerLedgerQueryKey(valid ? customerId : 0) } });
  if (!valid) return <><Header title="وردەکاری کڕیار" subtitle="ناسنامەی کڕیار دروست نییە." /><div className="surface state-box"><div className="state-icon"><Users /></div><h2 className="state-title">کڕیارەکە نەدۆزرایەوە</h2><p className="state-copy">ناسنامەی کڕیار دروست نییە یان لەبەردەستدا نییە.</p><Link href="/customers" className="button button-quiet">گەڕانەوە بۆ کڕیارەکان</Link></div></>;
  if (query.isLoading) return <><Header title="دفترچەی کڕیار" subtitle="هەموو فرۆشتن و پارەدانەکان لێرە کۆکراونەتەوە." /><LoadingState rows={2} /></>;
  if (query.isError || !query.data) return <><Header title="دفترچەی کڕیار" subtitle="هەموو فرۆشتن و پارەدانەکان لێرە کۆکراونەتەوە." /><ErrorState retry={() => query.refetch()} /></>;
  const { customer, sales, payments } = query.data;
  return <>
    <Header title="دفترچەی کڕیار" subtitle="مێژووی فرۆشتن و وەرگرتنی پارە." action={<Link href="/customers" className="button button-quiet"><ArrowLeft /> گەڕانەوە بۆ کڕیارەکان</Link>} />
    <section className="surface section-card" style={{ marginBottom: 14, display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 15, flexWrap: 'wrap' }}>
      <div><p className="eyebrow" style={{ marginBottom: 5 }}>زانیاریی کڕیار</p><h2 className="section-title" style={{ fontSize: 20 }}>{customer.name} {!customer.active && <span className="pill pill-muted" style={{ verticalAlign: 'middle' }}>لابراو</span>}</h2><div className="section-sub">{customer.phone || 'ژمارەی تەلەفۆن تۆمار نەکراوە'}{customer.notes ? ` · ${customer.notes}` : ''}</div></div>
      <div style={{ display: 'flex', gap: 15, flexWrap: 'wrap' }}><div><div className="secondary-cell">قەرزی دۆلار</div><div style={{ marginTop: 5 }}><Money amount={customer.debtUsd} currency="USD" /></div></div><div><div className="secondary-cell">قەرزی دینار</div><div style={{ marginTop: 5 }}><Money amount={customer.debtIqd} currency="IQD" /></div></div></div>
    </section>
    <div className="ledger-grid">
      <section className="surface section-card"><div className="section-head"><div><h2 className="section-title">فرۆشتنەکان</h2><p className="section-sub">{number(sales.length)} تۆمار</p></div><ShoppingBag size={18} color="#47745d" /></div>
        {sales.length ? <div style={{ display: 'grid', gap: 10 }}>{sales.map(s => <SaleCard key={s.id} sale={s} />)}</div> : <EmptyState icon={ReceiptText} title="فرۆشتنێک نییە" detail="فرۆشتنی ئەم کڕیارە لێرە دەردەکەوێت." />}</section>
      <section className="surface section-card"><div className="section-head"><div><h2 className="section-title">پارەدانەکان</h2><p className="section-sub">{number(payments.length)} تۆمار</p></div><Banknote size={18} color="#47745d" /></div>
        {payments.length ? <div style={{ display: 'grid', gap: 9 }}>{payments.map(p => <div key={p.id} style={{ padding: '12px 13px', border: '1px solid #ece9df', borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 10 }}><div><div className="primary-cell">وەرگرتنی پارە {!p.active && <span className="pill pill-muted">هەڵوەشێنراوە</span>}</div><div className="secondary-cell">{time(p.createdAt)}{p.note ? ` · ${p.note}` : ''}</div></div><div style={{ display: 'flex', alignItems: 'center', gap: 8 }}><Money amount={p.amount} currency={p.currency} /><PaymentStatusAction payment={p} /></div></div>)}</div> : <EmptyState icon={Banknote} title="پارەدانێک تۆمار نەکراوە" detail="پارەدانی وەرگیراو لە بەشی قەرزەکان تۆمار دەکرێت." />}</section>
    </div>
  </>;
}
function SaleCard({ sale }: { sale: Sale }) {
  return <article style={{ border: '1px solid #ece9df', borderRadius: 11, padding: 13 }}>
    <div style={{ display: 'flex', justifyContent: 'space-between', gap: 10, alignItems: 'start' }}><div><div className="primary-cell">{time(sale.createdAt)} {!sale.active && <span className="pill pill-muted">هەڵوەشێنراوە</span>}</div><div className="secondary-cell">{sale.staffName || 'کارمەند دیاری نەکراوە'}</div></div><div style={{ display: 'flex', alignItems: 'center', gap: 8 }}><CurrencyPair usd={sale.totalUsd} iqd={sale.totalIqd} /><SaleStatusAction sale={sale} /></div></div>
    <div style={{ borderTop: '1px solid #eeece4', marginTop: 10, paddingTop: 8, display: 'grid', gap: 5 }}>{sale.items.map(i => <div key={i.id} style={{ display: 'flex', justifyContent: 'space-between', gap: 9, fontSize: 10 }}><span>{i.productName} <span className="secondary-cell" style={{ display: 'inline' }}>× {number(i.quantity)}</span></span><Money amount={i.total} currency={i.currency} /></div>)}</div>
  </article>;
}

function SaleStatusAction({ sale }: { sale: Sale }) {
  const remove = useDeleteSale(); const restore = useUpdateSale(); const cache = useQueryClient();
  const refresh = () => Promise.all([
    cache.invalidateQueries({ queryKey: getListSalesQueryKey() }),
    cache.invalidateQueries({ queryKey: getGetCustomerLedgerQueryKey(sale.customerId) }),
    cache.invalidateQueries({ queryKey: getListDebtsQueryKey() }),
    cache.invalidateQueries({ queryKey: getListCustomersQueryKey() }),
    cache.invalidateQueries({ queryKey: getGetShopOverviewQueryKey() }),
  ]);
  function toggle() {
    if (sale.active) {
      if (!window.confirm('ئایا دڵنیایت لە هەڵوەشاندنەوەی ئەم فرۆشتنە؟ مێژووی مامەڵەکە دەمێنێتەوە.')) return;
      remove.mutate({ id: sale.id }, { onSuccess: refresh, onError: () => window.alert('هەڵوەشاندنەوەی فرۆشتن سەرکەوتوو نەبوو.') });
    } else {
      restore.mutate({ id: sale.id, data: { active: true } }, { onSuccess: refresh, onError: () => window.alert('گەڕاندنەوەی فرۆشتن سەرکەوتوو نەبوو.') });
    }
  }
  const pending = remove.isPending || restore.isPending;
  return <button className="icon-button" aria-label={sale.active ? 'هەڵوەشاندنەوەی فرۆشتن' : 'گەڕاندنەوەی فرۆشتن'} title={sale.active ? 'هەڵوەشاندنەوە' : 'گەڕاندنەوە'} onClick={toggle} disabled={pending} data-testid={`${sale.active ? 'button-void' : 'button-restore'}-sale-${sale.id}`}>{sale.active ? <Trash2 /> : <RefreshCw />}</button>;
}

function PaymentStatusAction({ payment }: { payment: DebtPayment }) {
  const remove = useDeleteDebtPayment(); const restore = useUpdateDebtPayment(); const cache = useQueryClient();
  const refresh = () => Promise.all([
    cache.invalidateQueries({ queryKey: getGetCustomerLedgerQueryKey(payment.customerId) }),
    cache.invalidateQueries({ queryKey: getListDebtsQueryKey() }),
    cache.invalidateQueries({ queryKey: getListCustomersQueryKey() }),
    cache.invalidateQueries({ queryKey: getGetShopOverviewQueryKey() }),
  ]);
  function toggle() {
    if (payment.active) {
      if (!window.confirm('ئایا دڵنیایت لە هەڵوەشاندنەوەی ئەم پارەدانە؟ مێژوویەکە دەمێنێتەوە و قەرز دووبارە هەژمار دەکرێتەوە.')) return;
      remove.mutate({ id: payment.id }, { onSuccess: refresh, onError: () => window.alert('هەڵوەشاندنەوەی پارەدان سەرکەوتوو نەبوو.') });
    } else {
      restore.mutate({ id: payment.id, data: { active: true } }, { onSuccess: refresh, onError: () => window.alert('گەڕاندنەوەی پارەدان سەرکەوتوو نەبوو. لەوانەیە قەرزی ماوە بۆ ئەم بڕە نەبێت.') });
    }
  }
  const pending = remove.isPending || restore.isPending;
  return <button className="icon-button" aria-label={payment.active ? 'هەڵوەشاندنەوەی پارەدان' : 'گەڕاندنەوەی پارەدان'} title={payment.active ? 'هەڵوەشاندنەوە' : 'گەڕاندنەوە'} onClick={toggle} disabled={pending} data-testid={`${payment.active ? 'button-void' : 'button-restore'}-payment-${payment.id}`}>{payment.active ? <Trash2 /> : <RefreshCw />}</button>;
}

function DebtsPage() {
  const query = useListDebts(); const cache = useQueryClient(); const [selected, setSelected] = useState<CustomerDebt | null>(null); const [search, setSearch] = useState('');
  const debts = query.data ?? []; const owing = debts.filter(d => d.debtUsd > 0 || d.debtIqd > 0);
  const usd = owing.reduce((sum, d) => sum + d.debtUsd, 0); const iqd = owing.reduce((sum, d) => sum + d.debtIqd, 0);
  const filtered = owing.filter(d => `${d.customerName} ${d.phone ?? ''}`.toLowerCase().includes(search.toLowerCase()));
  const refresh = () => Promise.all([cache.invalidateQueries({ queryKey: getListDebtsQueryKey() }), cache.invalidateQueries({ queryKey: getListCustomersQueryKey() }), cache.invalidateQueries({ queryKey: getGetShopOverviewQueryKey() })]);
  return <>
    <Header title="قەرزەکان" subtitle="باڵانسی قەرزدارەکان بە دراوی خۆیان ڕێک بخە." />
    {query.isLoading ? <LoadingState rows={2} /> : query.isError ? <ErrorState retry={() => query.refetch()} /> : <>
      <section className="debt-total"><div><div className="debt-total-label">کۆی قەرزی ماوە لە دوکان</div><div className="debt-total-val"><Money amount={usd} currency="USD" /><Money amount={iqd} currency="IQD" /></div></div><div className="debt-mark"><WalletCards /></div></section>
      <div className="toolbar"><SearchBox value={search} onChange={setSearch} placeholder="گەڕان بە ناوی کڕیار..." /><span className="pill pill-warn">{number(owing.length)} قەرزدار</span></div>
      <section className="surface section-card">{filtered.length ? <div className="table-wrap"><table><thead><tr><th>کڕیار</th><th>پەیوەندی</th><th>قەرزی دۆلار</th><th>قەرزی دینار</th><th>دوایین فرۆشتن</th><th>کردار</th></tr></thead><tbody>
        {filtered.map(d => <tr key={d.customerId} data-testid={`row-debt-${d.customerId}`}><td className="primary-cell">{d.customerName}</td><td>{d.phone || '—'}</td><td><Money amount={d.debtUsd} currency="USD" /></td><td><Money amount={d.debtIqd} currency="IQD" /></td><td>{date(d.lastPurchaseAt)}</td><td><Button small kind="quiet" onClick={() => setSelected(d)}><Plus /> تۆمارکردنی پارەدان</Button></td></tr>)}
      </tbody></table></div> : <EmptyState icon={WalletCards} title={search ? 'هیچ قەرزدارێک نەدۆزرایەوە' : 'قەرزی ماوە نییە'} detail={search ? 'گەڕانەکەت بگۆڕە.' : 'هەموو باڵانسەکان پاکن یان هێشتا قەرز تۆمار نەکراوە.'} />}</section>
    </>}
    {selected && <PaymentModal debt={selected} onClose={() => setSelected(null)} onSaved={() => { setSelected(null); void refresh(); }} />}
  </>;
}
function PaymentModal({ debt, onClose, onSaved }: { debt: CustomerDebt; onClose: () => void; onSaved: () => void }) {
  const mutation = useCreateDebtPayment(); const cache = useQueryClient(); const [currency, setCurrency] = useState<Currency>(debt.debtUsd > 0 ? 'USD' : 'IQD'); const [amount, setAmount] = useState(''); const [note, setNote] = useState(''); const [error, setError] = useState('');
  const remaining = currency === 'USD' ? debt.debtUsd : debt.debtIqd;
  function submit(e: FormEvent) { e.preventDefault(); setError(''); const val = Number(amount); if (!Number.isFinite(val) || val <= 0) { setError('بڕی پارەی دروست بنووسە.'); return; } if (val > remaining) { setError('بڕی پارەدان لە قەرزی ماوە زیاترە.'); return; }
    mutation.mutate({ data: { customerId: debt.customerId, amount: val, currency, note } }, { onSuccess: () => { void cache.invalidateQueries({ queryKey: getGetCustomerLedgerQueryKey(debt.customerId) }); onSaved(); }, onError: () => setError('تۆمارکردنی پارەدان سەرکەوتوو نەبوو.') });
  }
  return <Modal title="تۆمارکردنی پارەدان" subtitle={`پارەی وەرگیراو لە ${debt.customerName} تۆمار بکە.`} onClose={onClose}><form onSubmit={submit}><div className="notice" style={{ marginBottom: 14 }}>قەرزی ماوە: <Money amount={remaining} currency={currency} /></div><div className="form-grid">
    <Field label="دراوی پارەدان"><select className="select" value={currency} onChange={e => { setCurrency(e.target.value as Currency); setAmount(''); }} data-testid="select-payment-currency"><option value="USD">دۆلاری ئەمریکی · USD</option><option value="IQD">دیناری عێراقی · IQD</option></select></Field>
    <Field label="بڕی پارە"><input className="input" type="number" min="0.01" max={remaining} step="any" dir="ltr" value={amount} onChange={e => setAmount(e.target.value)} required data-testid="input-payment-amount" /></Field>
    <Field label="تێبینی" span><input className="input" value={note} onChange={e => setNote(e.target.value)} placeholder="ئارەزوومەندانە" data-testid="input-payment-note" /></Field>
  </div>{error && <p role="alert" style={{ color: '#a34436', fontSize: 11 }}>{error}</p>}<div className="modal-actions"><Button type="submit" disabled={mutation.isPending}>{mutation.isPending ? 'تۆمار دەکرێت...' : 'پاشەکەوتکردنی پارەدان'}</Button><Button kind="quiet" onClick={onClose}>پاشگەزبوونەوە</Button></div></form></Modal>;
}

function StaffPage() {
  const query = useListStaff(); const cache = useQueryClient(); const remove = useDeleteStaff(); const restore = useUpdateStaff();
  const [search, setSearch] = useState(''); const [showArchived, setShowArchived] = useState(false); const [editing, setEditing] = useState<Staff | null | undefined>(undefined);
  const staff = query.data ?? []; const filtered = staff.filter(s => (showArchived || s.active) && `${s.name} ${s.phone ?? ''} ${s.role ?? ''}`.toLowerCase().includes(search.toLowerCase()));
  const refresh = () => Promise.all([cache.invalidateQueries({ queryKey: getListStaffQueryKey() }), cache.invalidateQueries({ queryKey: getGetShopOverviewQueryKey() })]);
  const toggleActive = (person: Staff) => {
    if (person.active) {
      if (window.confirm(`ئایا دڵنیایت لە لابردنی «${person.name}»؟ مێژووی فرۆشتنی دەمێنێتەوە.`)) {
        remove.mutate({ id: person.id }, { onSuccess: refresh, onError: () => window.alert('لابردنی کارمەند سەرکەوتوو نەبوو.') });
      }
    } else {
      restore.mutate({ id: person.id, data: { active: true } }, { onSuccess: refresh, onError: () => window.alert('گەڕاندنەوەی کارمەند سەرکەوتوو نەبوو.') });
    }
  };
  return <>
    <Header title="کارمەندان" subtitle="زانیاریی ئەندامانی تیمی دوکان ڕێک بخە." action={<Button onClick={() => setEditing(null)}><Plus /> زیادکردنی کارمەند</Button>} />
    {query.isLoading ? <LoadingState rows={3} /> : query.isError ? <ErrorState retry={() => query.refetch()} /> : <>
      <div className="toolbar"><SearchBox value={search} onChange={setSearch} placeholder="گەڕان بە ناو، ئەرک یان مۆبایل..." /><span className="pill pill-muted">{number(staff.filter(s => s.active).length)} کارمەندی چالاک</span><ArchivedFilter checked={showArchived} onChange={setShowArchived} label="پیشاندانی کارمەندانی لابراو" /></div>
      <section className="surface section-card">{filtered.length ? <div className="table-wrap"><table><thead><tr><th>ناو</th><th>ئەرک</th><th>ژمارەی مۆبایل</th><th>بار</th><th>کردار</th></tr></thead><tbody>
        {filtered.map(s => <tr key={s.id} data-testid={`row-staff-${s.id}`}><td className="primary-cell">{s.name}</td><td>{s.role || 'ئەرک تۆمار نەکراوە'}</td><td>{s.phone || '—'}</td><td><span className={`pill${s.active ? '' : ' pill-muted'}`}>{s.active ? 'چالاک' : 'لابراو'}</span></td><td><div style={{ display: 'flex', gap: 3 }}><button className="icon-button" aria-label={`دەستکاری ${s.name}`} onClick={() => setEditing(s)} data-testid={`button-edit-staff-${s.id}`}><Pencil /></button><button className="icon-button" aria-label={s.active ? `لابردنی ${s.name}` : `گەڕاندنەوەی ${s.name}`} title={s.active ? 'لابردن' : 'گەڕاندنەوە'} onClick={() => toggleActive(s)} disabled={remove.isPending || restore.isPending} data-testid={`${s.active ? 'button-delete' : 'button-restore'}-staff-${s.id}`}>{s.active ? <Trash2 /> : <RefreshCw />}</button></div></td></tr>)}
      </tbody></table></div> : <EmptyState icon={ContactRound} title={search ? 'کارمەند نەدۆزرایەوە' : showArchived ? 'کارمەندێک نییە' : 'کارمەندی چالاک نییە'} detail={search ? 'وشەیەکی تر بگەڕێ.' : 'کارمەندی نوێ زیاد بکە یان کارمەندانی لابراو پیشان بدە.'} action={!search && <Button onClick={() => setEditing(null)}><Plus /> زیادکردنی کارمەند</Button>} />}</section>
    </>}
    {editing !== undefined && <StaffModal item={editing} onClose={() => setEditing(undefined)} onSaved={() => { setEditing(undefined); void refresh(); }} />}
  </>;
}
function StaffModal({ item, onClose, onSaved }: { item: Staff | null; onClose: () => void; onSaved: () => void }) {
  const create = useCreateStaff(); const update = useUpdateStaff(); const [name, setName] = useState(item?.name ?? ''); const [phone, setPhone] = useState(item?.phone ?? ''); const [role, setRole] = useState(item?.role ?? ''); const [active, setActive] = useState(item?.active ?? true); const [error, setError] = useState('');
  const pending = create.isPending || update.isPending;
  function submit(e: FormEvent) { e.preventDefault(); setError(''); if (!name.trim()) { setError('ناوی کارمەند پێویستە.'); return; }
    if (item) { const data: StaffUpdate = { name: name.trim(), phone, role, active }; update.mutate({ id: item.id, data }, { onSuccess: onSaved, onError: () => setError('نوێکردنەوە سەرکەوتوو نەبوو.') }); }
    else { const data: StaffInput = { name: name.trim(), phone, role }; create.mutate({ data }, { onSuccess: onSaved, onError: () => setError('زیادکردنی کارمەند سەرکەوتوو نەبوو.') }); }
  }
  return <Modal title={item ? 'دەستکاریکردنی کارمەند' : 'کارمەندی نوێ'} subtitle="ناو و پەیوەندیی کارمەند تۆمار بکە." onClose={onClose}><form onSubmit={submit}><div className="form-grid">
    <Field label="ناوی کارمەند" span><input className="input" autoFocus value={name} onChange={e => setName(e.target.value)} required data-testid="input-staff-name" /></Field>
    <Field label="ژمارەی مۆبایل"><input className="input" dir="ltr" value={phone} onChange={e => setPhone(e.target.value)} data-testid="input-staff-phone" /></Field>
    <Field label="ئەرک"><input className="input" value={role} onChange={e => setRole(e.target.value)} placeholder="ئەرک لە دوکان" data-testid="input-staff-role" /></Field>
    {item && <label className="span-2" style={{ display: 'flex', alignItems: 'center', gap: 9, fontSize: 11, fontWeight: 700, color: '#566c61' }}><input type="checkbox" checked={active} onChange={e => setActive(e.target.checked)} /> کارمەند چالاکە</label>}
  </div>{error && <p role="alert" style={{ color: '#a34436', fontSize: 11 }}>{error}</p>}<div className="modal-actions"><Button type="submit" disabled={pending}>{pending ? 'تۆمار دەکرێت...' : item ? 'پاشەکەوتکردن' : 'زیادکردنی کارمەند'}</Button><Button kind="quiet" onClick={onClose}>پاشگەزبوونەوە</Button></div></form></Modal>;
}

function SalesPage() {
  const query = useListSales(); const cache = useQueryClient(); const [creating, setCreating] = useState(false); const [search, setSearch] = useState(''); const [showVoided, setShowVoided] = useState(false);
  const sales = query.data ?? []; const filtered = sales.filter(s => (showVoided || s.active) && `${s.customerName} ${s.staffName ?? ''} ${s.note ?? ''}`.toLowerCase().includes(search.toLowerCase()));
  return <>
    <Header title="فرۆشتنەکان" subtitle="مێژووی فرۆشتن ببینە یان مامەڵەیەکی نوێ تۆمار بکە." action={<Button onClick={() => setCreating(true)}><Plus /> تۆمارکردنی فرۆشتن</Button>} />
    {query.isLoading ? <LoadingState rows={3} /> : query.isError ? <ErrorState retry={() => query.refetch()} /> : <>
      <div className="toolbar"><SearchBox value={search} onChange={setSearch} placeholder="گەڕان بە ناوی کڕیار یان کارمەند..." /><span className="pill pill-muted">{number(sales.filter(s => s.active).length)} فرۆشتنی چالاک</span><ArchivedFilter checked={showVoided} onChange={setShowVoided} label="پیشاندانی فرۆشتنی هەڵوەشێنراوە" /></div>
      <section className="surface section-card">{filtered.length ? <SalesTable sales={filtered} showActions /> : <EmptyState icon={ReceiptText} title={search ? 'فرۆشتن نەدۆزرایەوە' : showVoided ? 'فرۆشتنێک نییە' : 'فرۆشتنی چالاک نییە'} detail={search ? 'وشەیەکی تر بگەڕێ.' : 'فرۆشتنی نوێ تۆمار بکە یان فرۆشتنە هەڵوەشێنراوەکان پیشان بدە.'} action={!search && !showVoided && <Button onClick={() => setCreating(true)}><Plus /> تۆمارکردنی فرۆشتن</Button>} />}</section>
    </>}
    {creating && <SaleModal onClose={() => setCreating(false)} onSaved={() => { setCreating(false); void Promise.all([cache.invalidateQueries({ queryKey: getListSalesQueryKey() }), cache.invalidateQueries({ queryKey: getGetShopOverviewQueryKey() }), cache.invalidateQueries({ queryKey: getListCustomersQueryKey() }), cache.invalidateQueries({ queryKey: getListDebtsQueryKey() })]); }} />}
  </>;
}
type SaleDraft = { productId: string; quantity: string };
function SaleModal({ onClose, onSaved }: { onClose: () => void; onSaved: () => void }) {
  const productsQuery = useListProducts(); const customersQuery = useListCustomers(); const staffQuery = useListStaff(); const create = useCreateSale(); const cache = useQueryClient();
  const products = (productsQuery.data ?? []).filter(p => p.active); const customers = (customersQuery.data ?? []).filter(c => c.active); const staff = (staffQuery.data ?? []).filter(s => s.active);
  const [customerId, setCustomerId] = useState(''); const [staffId, setStaffId] = useState(''); const [note, setNote] = useState(''); const [lines, setLines] = useState<SaleDraft[]>([{ productId: '', quantity: '1' }]); const [error, setError] = useState('');
  const picked = lines.map(line => ({ line, product: products.find(p => String(p.id) === line.productId), quantity: Number(line.quantity) })).filter(x => x.product && x.quantity > 0);
  const totals = picked.reduce((acc, row) => { if (row.product?.currency === 'USD') acc.usd += row.product.price * row.quantity; else if (row.product?.currency === 'IQD') acc.iqd += row.product.price * row.quantity; return acc; }, { usd: 0, iqd: 0 });
  const initialLoading = productsQuery.isLoading || customersQuery.isLoading || staffQuery.isLoading;
  const failed = productsQuery.isError || customersQuery.isError || staffQuery.isError;
  function editLine(index: number, prop: keyof SaleDraft, value: string) { setLines(current => current.map((l, i) => i === index ? { ...l, [prop]: value } : l)); }
  function submit(e: FormEvent) { e.preventDefault(); setError('');
    if (!customerId) { setError('تکایە کڕیار دیاری بکە.'); return; }
    const items = lines.filter(l => l.productId && Number(l.quantity) > 0).map(l => ({ productId: Number(l.productId), quantity: Number(l.quantity) }));
    if (!items.length) { setError('بەلایەنی کەمەوە یەک کاڵا زیاد بکە.'); return; }
    const data: SaleInput = { customerId: Number(customerId), staffId: staffId ? Number(staffId) : null, note, items };
    create.mutate({ data }, { onSuccess: () => { void cache.invalidateQueries({ queryKey: getGetCustomerLedgerQueryKey(Number(customerId)) }); onSaved(); }, onError: () => setError('تۆمارکردنی فرۆشتن سەرکەوتوو نەبوو. وردەکارییەکان بپشکنە.') });
  }
  return <Modal title="تۆمارکردنی فرۆشتن" subtitle="کڕیار، کاڵاکان و بڕی وەرگیراو تۆمار بکە." onClose={onClose}>
    {initialLoading ? <><div className="skeleton skeleton-line" /><div className="skeleton skeleton-line" /><div className="skeleton skeleton-line" /></> : failed ? <ErrorState retry={() => { void productsQuery.refetch(); void customersQuery.refetch(); void staffQuery.refetch(); }} /> :
      <form onSubmit={submit}>
        {!customers.length && <div className="notice" style={{ marginBottom: 13 }}>پێش تۆمارکردنی فرۆشتن، کڕیارێک زیاد بکە.</div>}
        {!products.length && <div className="notice" style={{ marginBottom: 13 }}>کاڵای چالاک لە کاتەلۆگدا نییە.</div>}
        <div className="form-grid">
          <Field label="کڕیار"><select className="select" required value={customerId} onChange={e => setCustomerId(e.target.value)} data-testid="select-sale-customer"><option value="">کڕیار هەڵبژێرە</option>{customers.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}</select></Field>
          <Field label="کارمەند"><select className="select" value={staffId} onChange={e => setStaffId(e.target.value)} data-testid="select-sale-staff"><option value="">دیاری نەکراوە</option>{staff.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}</select></Field>
          <div className="span-2"><div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 9 }}><strong style={{ fontSize: 11, color: '#566c61' }}>کاڵاکانی فرۆشتن</strong><button type="button" className="link-subtle" onClick={() => setLines(v => [...v, { productId: '', quantity: '1' }])} data-testid="button-add-sale-line"><Plus size={13} style={{ verticalAlign: 'middle' }} /> زیادکردنی کاڵا</button></div>
            <div className="sale-items">{lines.map((line, index) => { const chosen = products.find(p => String(p.id) === line.productId); return <div className="sale-line" key={index}>
              <Field label={index === 0 ? 'کاڵا' : 'کاڵای تر'}><select className="select" value={line.productId} onChange={e => editLine(index, 'productId', e.target.value)} data-testid={`select-sale-product-${index}`}><option value="">کاڵا هەڵبژێرە</option>{products.map(p => <option key={p.id} value={p.id}>{p.name} · {number(p.price)} {p.currency}</option>)}</select>{chosen && <div className="inline-total"><Money amount={chosen.price * Number(line.quantity || 0)} currency={chosen.currency} /></div>}</Field>
              <Field label={index === 0 ? 'دانە' : 'دانە'}><input className="input" type="number" min="1" step="any" dir="ltr" value={line.quantity} onChange={e => editLine(index, 'quantity', e.target.value)} data-testid={`input-sale-quantity-${index}`} /></Field>
              <button type="button" className="icon-button" disabled={lines.length === 1} onClick={() => setLines(v => v.filter((_, i) => i !== index))} aria-label="لابردنی کاڵا" data-testid={`button-remove-sale-line-${index}`}><X /></button>
            </div>; })}</div>
          </div>
          <Field label="تێبینی" span><input className="input" value={note} onChange={e => setNote(e.target.value)} data-testid="input-sale-note" /></Field>
        </div>
        <div className="notice" style={{ marginTop: 14, display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 10 }}><span>کۆی فرۆشتن</span><CurrencyPair usd={totals.usd} iqd={totals.iqd} /></div>
        {error && <p role="alert" style={{ color: '#a34436', fontSize: 11 }}>{error}</p>}
        <div className="modal-actions"><Button type="submit" disabled={create.isPending || !customers.length || !products.length}>{create.isPending ? 'تۆمار دەکرێت...' : 'تۆمارکردنی فرۆشتن'}</Button><Button kind="quiet" onClick={onClose}>پاشگەزبوونەوە</Button></div>
      </form>}
  </Modal>;
}

function NotFound() {
  return <div className="surface state-box"><div className="state-icon"><FileText /></div><h1 className="state-title">ئەم پەڕەیە بوونی نییە</h1><p className="state-copy">ڕێڕەوەکە دروست نییە یان پەڕەکە گۆڕاوە.</p><Link href="/" className="button button-primary">گەڕانەوە بۆ سەرەتا</Link></div>;
}
function Router() {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}><AppShell /></ErrorBoundary>;
}
function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}

export default App;