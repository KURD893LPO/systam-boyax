import { and, desc, eq, gte, inArray, sql } from "drizzle-orm";
import { Router, type IRouter } from "express";
import {
  db,
  customersTable,
  currencyTransactionsTable,
  debtPaymentsTable,
  productsTable,
  saleItemsTable,
  salesTable,
  staffTable,
} from "@workspace/db";
import {
  CreateCustomerBody,
  CreateCustomerResponse,
  CreateExpenseBody,
  CreateExpenseResponse,
  CreateCurrencyTransactionBody,
  CreateCurrencyTransactionResponse,
  CreateDebtPaymentBody,
  CreateDebtPaymentResponse,
  CreateProductBody,
  CreateProductResponse,
  CreateSaleBody,
  CreateSaleResponse,
  CreateStaffBody,
  CreateStaffResponse,
  DeleteCustomerParams,
  DeleteDebtPaymentParams,
  DeleteSaleParams,
  DeleteStaffParams,
  GetCustomerLedgerParams,
  GetCustomerLedgerResponse,
  GetCurrencyAccountResponse,
  GetCurrencyRateResponse,
  GetShopOverviewResponse,
  ListCustomersResponse,
  ListDebtsResponse,
  ListExpensesResponse,
  ListProductsResponse,
  ListSalesResponse,
  ListSalesResponseItem,
  ListStaffResponse,
  UpdateCustomerBody,
  UpdateCustomerParams,
  UpdateCustomerResponse,
  UpdateDebtPaymentBody,
  UpdateDebtPaymentParams,
  UpdateDebtPaymentResponse,
  UpdateProductBody,
  UpdateProductParams,
  UpdateProductResponse,
  UpdateSaleBody,
  UpdateSaleParams,
  UpdateSaleResponse,
  UpdateStaffBody,
  UpdateStaffParams,
  UpdateStaffResponse,
  DeleteProductParams,
} from "@workspace/api-zod";

const router: IRouter = Router();
const cents = (value: number): number => Math.round((value + Number.EPSILON) * 100) / 100;
const numeric = (value: string | number): number => Number(value);
const iso = (value: Date): string => value.toISOString();
const currencyRateCacheRetryMs = 60 * 60 * 1000;
const currencyAccountLockId = 73020261;
type ShopCurrency = "USD" | "IQD";
type CurrencyTransactionRow = typeof currencyTransactionsTable.$inferSelect;

function currencyBalances(rows: CurrencyTransactionRow[]) {
  const balances: Record<ShopCurrency, number> = { USD: 0, IQD: 0 };
  for (const row of rows) {
    const amount = numeric(row.amount);
    if (row.kind === "deposit") {
      balances[row.currency] = cents(balances[row.currency] + amount);
    } else if (row.kind === "withdrawal" || row.kind === "expense") {
      balances[row.currency] = cents(balances[row.currency] - amount);
    } else {
      balances[row.currency] = cents(balances[row.currency] - amount);
      if (row.targetCurrency && row.targetAmount !== null) {
        balances[row.targetCurrency] = cents(balances[row.targetCurrency] + numeric(row.targetAmount));
      }
    }
  }
  return balances;
}

function currencyTransactionResponse(row: CurrencyTransactionRow) {
  return {
    id: row.id,
    kind: row.kind,
    currency: row.currency,
    amount: numeric(row.amount),
    ...(row.targetCurrency && row.targetAmount !== null && row.exchangeRate !== null
      ? {
          targetCurrency: row.targetCurrency,
          targetAmount: numeric(row.targetAmount),
          exchangeRate: numeric(row.exchangeRate),
        }
      : {}),
    ...(row.category ? { category: row.category } : {}),
    note: row.note,
    createdAt: iso(row.createdAt),
  };
}

type OpenAccessExchangeRate = {
  result?: unknown;
  base_code?: unknown;
  rates?: Record<string, unknown>;
  time_last_update_unix?: unknown;
  time_next_update_unix?: unknown;
};
type CurrencyRateData = {
  rate: number;
  updatedAt: Date;
  nextUpdateAt: Date;
  expiresAt: number;
};
let currencyRateCache: CurrencyRateData | null = null;

const catalogSeed: Array<{
  name: string;
  price: number;
  currency: "USD" | "IQD";
  category: string;
  unit: string;
}> = [
  { name: "ستڵ سپی خارجی", price: 55, currency: "USD", category: "بۆیاغ", unit: "دانە" },
  { name: "ستڵ سپی خارجی A03", price: 55, currency: "USD", category: "بۆیاغ", unit: "دانە" },
  { name: "ستڵ سپی خارجی A06", price: 55, currency: "USD", category: "بۆیاغ", unit: "دانە" },
  { name: "ستڵ سپی داخیلی", price: 47, currency: "USD", category: "بۆیاغ", unit: "دانە" },
  { name: "گاڵۆنی ڕۆنی لەمەع", price: 18, currency: "USD", category: "ڕۆن", unit: "گاڵۆن" },
  { name: "ڕۆنی کیلۆی", price: 5, currency: "USD", category: "ڕۆن", unit: "کیلۆ" },
  { name: "ئەساس", price: 42, currency: "USD", category: "بۆیاغ", unit: "دانە" },
  { name: "ستڵ ڕەش خارجی", price: 55, currency: "USD", category: "بۆیاغ", unit: "دانە" },
  { name: "ستڵ ڕەساسی خارجی", price: 55, currency: "USD", category: "بۆیاغ", unit: "دانە" },
  { name: "ستڵ سپی خارجی فول سلیکۆن", price: 75, currency: "USD", category: "بۆیاغ", unit: "دانە" },
  { name: "ستڵ سپی داخیلی فول سلیکۆن", price: 75, currency: "USD", category: "بۆیاغ", unit: "دانە" },
  { name: "فلیکۆت", price: 60, currency: "USD", category: "بۆیاغ", unit: "دانە" },
  { name: "ڕۆڵەی خارجی", price: 5000, currency: "IQD", category: "ڕۆڵە", unit: "دانە" },
  { name: "ڕۆڵەی داخیلی", price: 5000, currency: "IQD", category: "ڕۆڵە", unit: "دانە" },
  { name: "ڕۆڵەی ١٠ سم", price: 2000, currency: "IQD", category: "ڕۆڵە", unit: "دانە" },
  { name: "ڕۆڵەی ٧ سم", price: 2000, currency: "IQD", category: "ڕۆڵە", unit: "دانە" },
  { name: "ڕۆڵەی ١٥ سم", price: 3000, currency: "IQD", category: "ڕۆڵە", unit: "دانە" },
  { name: "سفرەی تێپ", price: 4000, currency: "IQD", category: "تێپ", unit: "دانە" },
  { name: "فڵچەی ٩٠ ملم", price: 3000, currency: "IQD", category: "فڵچە", unit: "دانە" },
  { name: "فڵچەی ٧٠ ملم", price: 2000, currency: "IQD", category: "فڵچە", unit: "دانە" },
  { name: "فڵچەی ڕۆبۆت", price: 5000, currency: "IQD", category: "فڵچە", unit: "دانە" },
  { name: "تێپی پانی دەبڵ", price: 2000, currency: "IQD", category: "تێپ", unit: "دانە" },
  { name: "مەعجون", price: 3500, currency: "IQD", category: "ئامراز", unit: "دانە" },
  { name: "شفرەی بچووک", price: 1500, currency: "IQD", category: "ئامراز", unit: "دانە" },
  { name: "فڵچەی ٢٠ ملم", price: 1000, currency: "IQD", category: "فڵچە", unit: "دانە" },
  { name: "فڵچەی ٣٠ ملم", price: 1500, currency: "IQD", category: "فڵچە", unit: "دانە" },
  { name: "شفرەی گەوڕا", price: 5000, currency: "IQD", category: "ئامراز", unit: "دانە" },
];

let catalogSeedPromise: Promise<void> | undefined;
function ensureCatalogSeeded(): Promise<void> {
  catalogSeedPromise ??= db
    .insert(productsTable)
    .values(catalogSeed.map((product) => ({ ...product, price: String(product.price) })))
    .onConflictDoNothing({ target: productsTable.name })
    .then(() => undefined);
  return catalogSeedPromise;
}

function productResponse(product: typeof productsTable.$inferSelect) {
  return {
    ...product,
    price: numeric(product.price),
    createdAt: iso(product.createdAt),
  };
}

async function getDebtBalances(customerId?: number) {
  const allSales = await db
    .select({
      customerId: salesTable.customerId,
      totalUsd: salesTable.totalUsd,
      totalIqd: salesTable.totalIqd,
      paidUsd: salesTable.paidUsd,
      paidIqd: salesTable.paidIqd,
    })
    .from(salesTable)
    .where(customerId === undefined
      ? eq(salesTable.active, true)
      : and(eq(salesTable.customerId, customerId), eq(salesTable.active, true)));
  const allPayments = await db
    .select({
      customerId: debtPaymentsTable.customerId,
      amount: debtPaymentsTable.amount,
      currency: debtPaymentsTable.currency,
    })
    .from(debtPaymentsTable)
    .where(customerId === undefined
      ? eq(debtPaymentsTable.active, true)
      : and(eq(debtPaymentsTable.customerId, customerId), eq(debtPaymentsTable.active, true)));

  const balances = new Map<number, { debtUsd: number; debtIqd: number }>();
  const balanceFor = (id: number) => {
    let balance = balances.get(id);
    if (!balance) {
      balance = { debtUsd: 0, debtIqd: 0 };
      balances.set(id, balance);
    }
    return balance;
  };
  for (const row of allSales) {
    const balance = balanceFor(row.customerId);
    balance.debtUsd += numeric(row.totalUsd) - numeric(row.paidUsd);
    balance.debtIqd += numeric(row.totalIqd) - numeric(row.paidIqd);
  }
  for (const row of allPayments) {
    const balance = balanceFor(row.customerId);
    if (row.currency === "USD") balance.debtUsd -= numeric(row.amount);
    else balance.debtIqd -= numeric(row.amount);
  }
  for (const balance of balances.values()) {
    balance.debtUsd = cents(Math.max(0, balance.debtUsd));
    balance.debtIqd = cents(Math.max(0, balance.debtIqd));
  }
  return balances;
}

async function listSales(customerId?: number, limit = 200, activeOnly = false) {
  const columns = {
    id: salesTable.id,
    customerId: salesTable.customerId,
    customerName: customersTable.name,
    staffId: salesTable.staffId,
    staffName: staffTable.name,
    note: salesTable.note,
    totalUsd: salesTable.totalUsd,
    totalIqd: salesTable.totalIqd,
    paidUsd: salesTable.paidUsd,
    paidIqd: salesTable.paidIqd,
    active: salesTable.active,
    createdAt: salesTable.createdAt,
  };
  const query = db
    .select(columns)
    .from(salesTable)
    .innerJoin(customersTable, eq(salesTable.customerId, customersTable.id))
    .leftJoin(staffTable, eq(salesTable.staffId, staffTable.id));
  const filters = [
    customerId === undefined ? undefined : eq(salesTable.customerId, customerId),
    activeOnly ? eq(salesTable.active, true) : undefined,
  ];
  const filter = and(...filters.filter((value): value is NonNullable<typeof value> => value !== undefined));
  const rows = await query.where(filter).orderBy(desc(salesTable.createdAt)).limit(limit);

  if (rows.length === 0) return [];
  const ids = rows.map((row) => row.id);
  const lineRows = await db
    .select()
    .from(saleItemsTable)
    .where(inArray(saleItemsTable.saleId, ids));
  const linesBySale = new Map<number, typeof lineRows>();
  for (const line of lineRows) {
    const current = linesBySale.get(line.saleId) ?? [];
    current.push(line);
    linesBySale.set(line.saleId, current);
  }

  return rows.map((row) =>
    ListSalesResponseItem.parse({
      id: row.id,
      customerId: row.customerId,
      customerName: row.customerName,
      staffId: row.staffId,
      staffName: row.staffName,
      note: row.note,
      items: (linesBySale.get(row.id) ?? []).map((line) => ({
        id: line.id,
        productId: line.productId,
        productName: line.productName,
        quantity: line.quantity,
        unitPrice: numeric(line.unitPrice),
        currency: line.currency,
        total: numeric(line.total),
      })),
      totalUsd: numeric(row.totalUsd),
      totalIqd: numeric(row.totalIqd),
      paidUsd: numeric(row.paidUsd),
      paidIqd: numeric(row.paidIqd),
      active: row.active,
      createdAt: iso(row.createdAt),
    }),
  );
}

router.get("/shop/overview", async (_req, res): Promise<void> => {
  await ensureCatalogSeeded();
  const localNow = new Date(Date.now() + 3 * 60 * 60 * 1000);
  localNow.setUTCHours(0, 0, 0, 0);
  const startOfBaghdadDay = new Date(localNow.getTime() - 3 * 60 * 60 * 1000);
  const [products, customers, staff, allSales, balances] = await Promise.all([
    db.select({ count: sql<number>`count(*)::int` }).from(productsTable).where(eq(productsTable.active, true)),
    db.select({ count: sql<number>`count(*)::int` }).from(customersTable).where(eq(customersTable.active, true)),
    db.select({ count: sql<number>`count(*)::int` }).from(staffTable).where(eq(staffTable.active, true)),
    db.select().from(salesTable).where(and(gte(salesTable.createdAt, startOfBaghdadDay), eq(salesTable.active, true))),
    getDebtBalances(),
  ]);
  const todayUsd = allSales.reduce((total, sale) => total + numeric(sale.totalUsd), 0);
  const todayIqd = allSales.reduce((total, sale) => total + numeric(sale.totalIqd), 0);
  const debts = [...balances.values()].reduce(
    (total, item) => ({
      usd: total.usd + item.debtUsd,
      iqd: total.iqd + item.debtIqd,
    }),
    { usd: 0, iqd: 0 },
  );
  const response = {
    productCount: products[0]?.count ?? 0,
    customerCount: customers[0]?.count ?? 0,
    staffCount: staff[0]?.count ?? 0,
    salesToday: allSales.length,
    salesTodayUsd: cents(todayUsd),
    salesTodayIqd: cents(todayIqd),
    debtUsd: cents(debts.usd),
    debtIqd: cents(debts.iqd),
     recentSales: await listSales(undefined, 6, true),
  };
  res.json(GetShopOverviewResponse.parse(response));
});

router.get("/products", async (_req, res): Promise<void> => {
  await ensureCatalogSeeded();
  const products = await db.select().from(productsTable).orderBy(desc(productsTable.active), productsTable.name);
  res.json(ListProductsResponse.parse(products.map(productResponse)));
});

router.post("/products", async (req, res): Promise<void> => {
  const parsed = CreateProductBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [product] = await db
    .insert(productsTable)
    .values({
      ...parsed.data,
      price: String(parsed.data.price),
      category: parsed.data.category ?? "کالا",
      unit: parsed.data.unit ?? "دانە",
    })
    .returning();
  res.status(201).json(CreateProductResponse.parse(productResponse(product)));
});

router.patch("/products/:id", async (req, res): Promise<void> => {
  const params = UpdateProductParams.safeParse(req.params);
  const parsed = UpdateProductBody.safeParse(req.body);
  if (!params.success || !parsed.success) {
    res.status(400).json({ error: params.error?.message ?? parsed.error?.message });
    return;
  }
  const [product] = await db
    .update(productsTable)
    .set({
      ...parsed.data,
      price: parsed.data.price === undefined ? undefined : String(parsed.data.price),
    })
    .where(eq(productsTable.id, params.data.id))
    .returning();
  if (!product) {
    res.status(404).json({ error: "Product not found" });
    return;
  }
  res.json(UpdateProductResponse.parse(productResponse(product)));
});

router.delete("/products/:id", async (req, res): Promise<void> => {
  const params = DeleteProductParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [product] = await db
    .update(productsTable)
    .set({ active: false })
    .where(eq(productsTable.id, params.data.id))
    .returning({ id: productsTable.id });
  if (!product) {
    res.status(404).json({ error: "Product not found" });
    return;
  }
  res.sendStatus(204);
});

router.get("/customers", async (_req, res): Promise<void> => {
  const [customers, balances] = await Promise.all([
    db.select().from(customersTable).orderBy(desc(customersTable.active), customersTable.name),
    getDebtBalances(),
  ]);
  res.json(
    ListCustomersResponse.parse(
      customers.map((customer) => ({
        ...customer,
        phone: customer.phone,
        notes: customer.notes,
        debtUsd: balances.get(customer.id)?.debtUsd ?? 0,
        debtIqd: balances.get(customer.id)?.debtIqd ?? 0,
        createdAt: iso(customer.createdAt),
      })),
    ),
  );
});

router.post("/customers", async (req, res): Promise<void> => {
  const parsed = CreateCustomerBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [customer] = await db.insert(customersTable).values(parsed.data).returning();
  res.status(201).json(
    CreateCustomerResponse.parse({
      ...customer,
      debtUsd: 0,
      debtIqd: 0,
      createdAt: iso(customer.createdAt),
    }),
  );
});

router.patch("/customers/:id", async (req, res): Promise<void> => {
  const params = UpdateCustomerParams.safeParse(req.params);
  const parsed = UpdateCustomerBody.safeParse(req.body);
  if (!params.success || !parsed.success) {
    res.status(400).json({ error: params.error?.message ?? parsed.error?.message });
    return;
  }
  const [customer] = await db
    .update(customersTable)
    .set(parsed.data)
    .where(eq(customersTable.id, params.data.id))
    .returning();
  if (!customer) {
    res.status(404).json({ error: "Customer not found" });
    return;
  }
  const balances = await getDebtBalances(customer.id);
  res.json(
    UpdateCustomerResponse.parse({
      ...customer,
      debtUsd: balances.get(customer.id)?.debtUsd ?? 0,
      debtIqd: balances.get(customer.id)?.debtIqd ?? 0,
      createdAt: iso(customer.createdAt),
    }),
  );
});

router.delete("/customers/:id", async (req, res): Promise<void> => {
  const params = DeleteCustomerParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [customer] = await db
    .update(customersTable)
    .set({ active: false })
    .where(eq(customersTable.id, params.data.id))
    .returning({ id: customersTable.id });
  if (!customer) {
    res.status(404).json({ error: "Customer not found" });
    return;
  }
  res.sendStatus(204);
});

router.get("/customers/:id/ledger", async (req, res): Promise<void> => {
  const params = GetCustomerLedgerParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [customer] = await db.select().from(customersTable).where(eq(customersTable.id, params.data.id)).limit(1);
  if (!customer) {
    res.status(404).json({ error: "Customer not found" });
    return;
  }
  const [balances, sales, payments] = await Promise.all([
    getDebtBalances(customer.id),
    listSales(customer.id),
    db
      .select({
        id: debtPaymentsTable.id,
        customerId: debtPaymentsTable.customerId,
        customerName: customersTable.name,
        amount: debtPaymentsTable.amount,
        currency: debtPaymentsTable.currency,
        note: debtPaymentsTable.note,
        active: debtPaymentsTable.active,
        createdAt: debtPaymentsTable.createdAt,
      })
      .from(debtPaymentsTable)
      .innerJoin(customersTable, eq(debtPaymentsTable.customerId, customersTable.id))
      .where(eq(debtPaymentsTable.customerId, customer.id))
      .orderBy(desc(debtPaymentsTable.createdAt)),
  ]);
  const ledger = {
    customer: {
      ...customer,
      debtUsd: balances.get(customer.id)?.debtUsd ?? 0,
      debtIqd: balances.get(customer.id)?.debtIqd ?? 0,
      createdAt: iso(customer.createdAt),
    },
    sales,
    payments: payments.map((payment) => ({ ...payment, amount: numeric(payment.amount), createdAt: iso(payment.createdAt) })),
  };
  res.json(GetCustomerLedgerResponse.parse(ledger));
});

router.get("/staff", async (_req, res): Promise<void> => {
  const staff = await db.select().from(staffTable).orderBy(desc(staffTable.active), staffTable.name);
  res.json(ListStaffResponse.parse(staff.map((person) => ({ ...person, createdAt: iso(person.createdAt) }))));
});

router.post("/staff", async (req, res): Promise<void> => {
  const parsed = CreateStaffBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [person] = await db.insert(staffTable).values(parsed.data).returning();
  res.status(201).json(CreateStaffResponse.parse({ ...person, createdAt: iso(person.createdAt) }));
});

router.patch("/staff/:id", async (req, res): Promise<void> => {
  const params = UpdateStaffParams.safeParse(req.params);
  const parsed = UpdateStaffBody.safeParse(req.body);
  if (!params.success || !parsed.success) {
    res.status(400).json({ error: params.error?.message ?? parsed.error?.message });
    return;
  }
  const [person] = await db
    .update(staffTable)
    .set(parsed.data)
    .where(eq(staffTable.id, params.data.id))
    .returning();
  if (!person) {
    res.status(404).json({ error: "Staff member not found" });
    return;
  }
  res.json(UpdateStaffResponse.parse({ ...person, createdAt: iso(person.createdAt) }));
});

router.delete("/staff/:id", async (req, res): Promise<void> => {
  const params = DeleteStaffParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [person] = await db
    .update(staffTable)
    .set({ active: false })
    .where(eq(staffTable.id, params.data.id))
    .returning({ id: staffTable.id });
  if (!person) {
    res.status(404).json({ error: "Staff member not found" });
    return;
  }
  res.sendStatus(204);
});

router.get("/sales", async (_req, res): Promise<void> => {
  res.json(ListSalesResponse.parse(await listSales()));
});

router.patch("/sales/:id", async (req, res): Promise<void> => {
  const params = UpdateSaleParams.safeParse(req.params);
  const parsed = UpdateSaleBody.safeParse(req.body);
  if (!params.success || !parsed.success) {
    res.status(400).json({ error: params.error?.message ?? parsed.error?.message });
    return;
  }
  const [updated] = await db
    .update(salesTable)
    .set({ active: parsed.data.active })
    .where(eq(salesTable.id, params.data.id))
    .returning({ id: salesTable.id });
  if (!updated) {
    res.status(404).json({ error: "Sale not found" });
    return;
  }
  const sale = (await listSales()).find((item) => item.id === updated.id);
  if (!sale) {
    res.status(500).json({ error: "Sale status was updated but could not be loaded" });
    return;
  }
  res.json(UpdateSaleResponse.parse(sale));
});

router.delete("/sales/:id", async (req, res): Promise<void> => {
  const params = DeleteSaleParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [sale] = await db
    .update(salesTable)
    .set({ active: false })
    .where(eq(salesTable.id, params.data.id))
    .returning({ id: salesTable.id });
  if (!sale) {
    res.status(404).json({ error: "Sale not found" });
    return;
  }
  res.sendStatus(204);
});

router.post("/sales", async (req, res): Promise<void> => {
  const parsed = CreateSaleBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const body = parsed.data;
  const saleId = await db.transaction(async (tx) => {
    const [customer] = await tx.select({ id: customersTable.id }).from(customersTable).where(and(eq(customersTable.id, body.customerId), eq(customersTable.active, true))).limit(1);
    if (!customer) throw new Error("CUSTOMER_NOT_FOUND");
    if (body.staffId != null) {
      const [staff] = await tx.select({ id: staffTable.id }).from(staffTable).where(and(eq(staffTable.id, body.staffId), eq(staffTable.active, true))).limit(1);
      if (!staff) throw new Error("STAFF_NOT_FOUND");
    }
    const productIds = [...new Set(body.items.map((item) => item.productId))];
    const products = await tx.select().from(productsTable).where(inArray(productsTable.id, productIds));
    if (products.length !== productIds.length || products.some((product) => !product.active)) throw new Error("PRODUCT_NOT_FOUND");
    const productMap = new Map(products.map((product) => [product.id, product]));
    const lines = body.items.map((item) => {
      const product = productMap.get(item.productId)!;
      const unitPrice = numeric(product.price);
      return {
        productId: product.id,
        productName: product.name,
        quantity: item.quantity,
        unitPrice,
        currency: product.currency,
        total: cents(unitPrice * item.quantity),
      };
    });
    const totals = lines.reduce(
      (sum, line) => {
        if (line.currency === "USD") sum.usd += line.total;
        else sum.iqd += line.total;
        return sum;
      },
      { usd: 0, iqd: 0 },
    );
    const paidUsd = cents(body.paidUsd ?? 0);
    const paidIqd = cents(body.paidIqd ?? 0);
    if (paidUsd > cents(totals.usd) || paidIqd > cents(totals.iqd)) throw new Error("PAYMENT_EXCEEDS_TOTAL");
    const [sale] = await tx
      .insert(salesTable)
      .values({
        customerId: body.customerId,
        staffId: body.staffId ?? null,
        note: body.note ?? null,
        totalUsd: String(cents(totals.usd)),
        totalIqd: String(cents(totals.iqd)),
        paidUsd: String(paidUsd),
        paidIqd: String(paidIqd),
      })
      .returning({ id: salesTable.id });
    await tx.insert(saleItemsTable).values(
      lines.map((line) => ({
        saleId: sale.id,
        productId: line.productId,
        productName: line.productName,
        quantity: line.quantity,
        unitPrice: String(line.unitPrice),
        currency: line.currency,
        total: String(line.total),
      })),
    );
    return sale.id;
  }).catch((error: unknown) => {
    if (error instanceof Error && ["CUSTOMER_NOT_FOUND", "STAFF_NOT_FOUND", "PRODUCT_NOT_FOUND", "PAYMENT_EXCEEDS_TOTAL"].includes(error.message)) {
      return error.message;
    }
    throw error;
  });

  if (typeof saleId === "string") {
    res.status(400).json({ error: saleId });
    return;
  }
  const sale = (await listSales(body.customerId)).find((item) => item.id === saleId);
  if (!sale) {
    res.status(500).json({ error: "Sale was recorded but could not be loaded" });
    return;
  }
  res.status(201).json(CreateSaleResponse.parse(sale));
});

router.get("/debts", async (_req, res): Promise<void> => {
  const [customers, balances, sales] = await Promise.all([
    db.select().from(customersTable),
    getDebtBalances(),
    db
      .select({ customerId: salesTable.customerId, createdAt: salesTable.createdAt })
      .from(salesTable)
      .where(eq(salesTable.active, true)),
  ]);
  const lastPurchase = new Map<number, Date>();
  for (const sale of sales) {
    const previous = lastPurchase.get(sale.customerId);
    if (!previous || sale.createdAt > previous) lastPurchase.set(sale.customerId, sale.createdAt);
  }
  const rows = customers
    .map((customer) => ({
      customerId: customer.id,
      customerName: customer.name,
      phone: customer.phone,
      debtUsd: balances.get(customer.id)?.debtUsd ?? 0,
      debtIqd: balances.get(customer.id)?.debtIqd ?? 0,
      lastPurchaseAt: lastPurchase.has(customer.id) ? iso(lastPurchase.get(customer.id)!) : null,
    }))
    .filter((row) => row.debtUsd > 0 || row.debtIqd > 0)
    .sort((a, b) => (b.lastPurchaseAt ?? "").localeCompare(a.lastPurchaseAt ?? ""));
  res.json(ListDebtsResponse.parse(rows));
});

router.post("/debt-payments", async (req, res): Promise<void> => {
  const parsed = CreateDebtPaymentBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const payment = parsed.data;
  const inserted = await db.transaction(async (tx) => {
    const [customer] = await tx
      .select({ id: customersTable.id, name: customersTable.name })
      .from(customersTable)
      .where(eq(customersTable.id, payment.customerId))
      .for("update")
      .limit(1);
    if (!customer) throw new Error("CUSTOMER_NOT_FOUND");
    const saleRows = await tx.select().from(salesTable).where(and(eq(salesTable.customerId, customer.id), eq(salesTable.active, true)));
    const paymentRows = await tx
      .select({ amount: debtPaymentsTable.amount, currency: debtPaymentsTable.currency })
      .from(debtPaymentsTable)
      .where(and(eq(debtPaymentsTable.customerId, customer.id), eq(debtPaymentsTable.active, true)));
    const owedFromSales = saleRows.reduce(
      (total, sale) => ({
        USD: total.USD + numeric(sale.totalUsd) - numeric(sale.paidUsd),
        IQD: total.IQD + numeric(sale.totalIqd) - numeric(sale.paidIqd),
      }),
      { USD: 0, IQD: 0 },
    );
    for (const previous of paymentRows) owedFromSales[previous.currency] -= numeric(previous.amount);
    if (payment.amount > cents(Math.max(0, owedFromSales[payment.currency])) + 0.001) throw new Error("PAYMENT_EXCEEDS_DEBT");
    const [row] = await tx.insert(debtPaymentsTable).values({
      customerId: payment.customerId,
      amount: String(cents(payment.amount)),
      currency: payment.currency,
      note: payment.note ?? null,
    }).returning();
    return { ...row, customerName: customer.name };
  }).catch((error: unknown) => {
    if (error instanceof Error && ["CUSTOMER_NOT_FOUND", "PAYMENT_EXCEEDS_DEBT"].includes(error.message)) return error.message;
    throw error;
  });
  if (typeof inserted === "string") {
    res.status(400).json({ error: inserted });
    return;
  }
  res.status(201).json(
    CreateDebtPaymentResponse.parse({
      ...inserted,
      amount: numeric(inserted.amount),
      createdAt: iso(inserted.createdAt),
    }),
  );
});

router.patch("/debt-payments/:id", async (req, res): Promise<void> => {
  const params = UpdateDebtPaymentParams.safeParse(req.params);
  const parsed = UpdateDebtPaymentBody.safeParse(req.body);
  if (!params.success || !parsed.success) {
    res.status(400).json({ error: params.error?.message ?? parsed.error?.message });
    return;
  }

  const result = await db.transaction(async (tx) => {
    const [reference] = await tx
      .select({ customerId: debtPaymentsTable.customerId })
      .from(debtPaymentsTable)
      .where(eq(debtPaymentsTable.id, params.data.id))
      .limit(1);
    if (!reference) return "PAYMENT_NOT_FOUND";

    const [customer] = await tx
      .select({ id: customersTable.id })
      .from(customersTable)
      .where(eq(customersTable.id, reference.customerId))
      .for("update")
      .limit(1);
    if (!customer) return "CUSTOMER_NOT_FOUND";

    const [payment] = await tx
      .select()
      .from(debtPaymentsTable)
      .where(eq(debtPaymentsTable.id, params.data.id))
      .for("update")
      .limit(1);
    if (!payment) return "PAYMENT_NOT_FOUND";

    if (parsed.data.active && !payment.active) {
      const [saleRows, paymentRows] = await Promise.all([
        tx.select().from(salesTable).where(and(eq(salesTable.customerId, customer.id), eq(salesTable.active, true))),
        tx
          .select({ amount: debtPaymentsTable.amount, currency: debtPaymentsTable.currency })
          .from(debtPaymentsTable)
          .where(and(eq(debtPaymentsTable.customerId, customer.id), eq(debtPaymentsTable.active, true))),
      ]);
      const owed = saleRows.reduce(
        (total, sale) => ({
          USD: total.USD + numeric(sale.totalUsd) - numeric(sale.paidUsd),
          IQD: total.IQD + numeric(sale.totalIqd) - numeric(sale.paidIqd),
        }),
        { USD: 0, IQD: 0 },
      );
      for (const previous of paymentRows) owed[previous.currency] -= numeric(previous.amount);
      if (numeric(payment.amount) > cents(Math.max(0, owed[payment.currency])) + 0.001) {
        return "PAYMENT_EXCEEDS_DEBT";
      }
    }

    const [updated] = await tx
      .update(debtPaymentsTable)
      .set({ active: parsed.data.active })
      .where(eq(debtPaymentsTable.id, payment.id))
      .returning();
    return updated;
  });

  if (typeof result === "string") {
    const status = result === "PAYMENT_NOT_FOUND" ? 404 : 400;
    res.status(status).json({ error: result });
    return;
  }
  const [customer] = await db
    .select({ name: customersTable.name })
    .from(customersTable)
    .where(eq(customersTable.id, result.customerId))
    .limit(1);
  if (!customer) {
    res.status(500).json({ error: "Payment status was updated but its customer could not be loaded" });
    return;
  }
  res.json(UpdateDebtPaymentResponse.parse({
    ...result,
    customerName: customer.name,
    amount: numeric(result.amount),
    createdAt: iso(result.createdAt),
  }));
});

router.delete("/debt-payments/:id", async (req, res): Promise<void> => {
  const params = DeleteDebtPaymentParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [payment] = await db
    .update(debtPaymentsTable)
    .set({ active: false })
    .where(eq(debtPaymentsTable.id, params.data.id))
    .returning({ id: debtPaymentsTable.id });
  if (!payment) {
    res.status(404).json({ error: "Debt payment not found" });
    return;
  }
  res.sendStatus(204);
});

router.get("/currency-rate", async (req, res): Promise<void> => {
  try {
    res.setHeader("Cache-Control", "public, max-age=3600");
    if (currencyRateCache && Date.now() < currencyRateCache.expiresAt) {
      res.json(
        GetCurrencyRateResponse.parse({
          pair: "USD/IQD",
          rate: currencyRateCache.rate,
          source: "ExchangeRate-API",
          updatedAt: iso(currencyRateCache.updatedAt),
          nextUpdateAt: iso(currencyRateCache.nextUpdateAt),
        }),
      );
      return;
    }

    const providerResponse = await fetch("https://open.er-api.com/v6/latest/USD", {
      headers: { accept: "application/json" },
      signal: AbortSignal.timeout(8_000),
    });
    if (!providerResponse.ok) throw new Error(`Rate provider returned ${providerResponse.status}`);
    const providerData = (await providerResponse.json()) as OpenAccessExchangeRate;
    const rate = providerData.rates?.IQD;
    const updatedAtSeconds = Number(providerData.time_last_update_unix);
    const nextUpdateAtSeconds = Number(providerData.time_next_update_unix);
    if (
      providerData.result !== "success" ||
      providerData.base_code !== "USD" ||
      typeof rate !== "number" ||
      !Number.isFinite(rate) ||
      rate <= 0 ||
      !Number.isFinite(updatedAtSeconds) ||
      !Number.isFinite(nextUpdateAtSeconds)
    ) {
      throw new Error("Rate provider returned an invalid USD/IQD response");
    }

    const updatedAt = new Date(updatedAtSeconds * 1000);
    const nextUpdateAt = new Date(nextUpdateAtSeconds * 1000);
    currencyRateCache = {
      rate,
      updatedAt,
      nextUpdateAt,
      expiresAt: Math.max(Date.now() + currencyRateCacheRetryMs, nextUpdateAt.getTime() + currencyRateCacheRetryMs),
    };
    res.json(
      GetCurrencyRateResponse.parse({
        pair: "USD/IQD",
        rate: currencyRateCache.rate,
        source: "ExchangeRate-API",
        updatedAt: iso(currencyRateCache.updatedAt),
        nextUpdateAt: iso(currencyRateCache.nextUpdateAt),
      }),
    );
  } catch (error) {
    req.log.warn({ err: error }, "Unable to retrieve the online USD/IQD reference rate");
    res.status(502).json({ error: "RATE_PROVIDER_UNAVAILABLE" });
  }
});

router.get("/currency-account", async (_req, res): Promise<void> => {
  const rows = await db.select().from(currencyTransactionsTable).orderBy(desc(currencyTransactionsTable.createdAt), desc(currencyTransactionsTable.id));
  const balances = currencyBalances(rows);
  res.json(
    GetCurrencyAccountResponse.parse({
      balanceUsd: balances.USD,
      balanceIqd: balances.IQD,
      transactions: rows.map(currencyTransactionResponse),
    }),
  );
});

router.get("/expenses", async (_req, res): Promise<void> => {
  const rows = await db
    .select()
    .from(currencyTransactionsTable)
    .where(eq(currencyTransactionsTable.kind, "expense"))
    .orderBy(desc(currencyTransactionsTable.createdAt), desc(currencyTransactionsTable.id));
  res.json(
    ListExpensesResponse.parse(
      rows.map((row) => ({
        id: row.id,
        category: row.category ?? "خەرجی گشتی",
        currency: row.currency,
        amount: numeric(row.amount),
        note: row.note,
        createdAt: iso(row.createdAt),
      })),
    ),
  );
});

router.post("/expenses", async (req, res): Promise<void> => {
  const parsed = CreateExpenseBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const input = parsed.data;
  const amount = cents(input.amount);
  const category = input.category.trim();
  if (amount <= 0) {
    res.status(400).json({ error: "AMOUNT_TOO_SMALL" });
    return;
  }
  if (!category) {
    res.status(400).json({ error: "EXPENSE_CATEGORY_REQUIRED" });
    return;
  }

  const result = await db.transaction(async (tx) => {
    await tx.execute(sql`SELECT pg_advisory_xact_lock(${currencyAccountLockId})`);
    const previousRows = await tx.select().from(currencyTransactionsTable);
    const balances = currencyBalances(previousRows);
    if (balances[input.currency] + 0.001 < amount) {
      return "INSUFFICIENT_CURRENCY_BALANCE";
    }

    const [row] = await tx
      .insert(currencyTransactionsTable)
      .values({
        kind: "expense",
        currency: input.currency,
        amount: String(amount),
        targetCurrency: null,
        targetAmount: null,
        exchangeRate: null,
        category,
        note: input.note ?? null,
      })
      .returning();
    return row;
  });

  if (typeof result === "string") {
    res.status(400).json({ error: result });
    return;
  }
  res.status(201).json(
    CreateExpenseResponse.parse({
      id: result.id,
      category: result.category ?? category,
      currency: result.currency,
      amount: numeric(result.amount),
      note: result.note,
      createdAt: iso(result.createdAt),
    }),
  );
});

router.post("/currency-transactions", async (req, res): Promise<void> => {
  const parsed = CreateCurrencyTransactionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const input = parsed.data;
  const amount = cents(input.amount);
  if (amount <= 0) {
    res.status(400).json({ error: "AMOUNT_TOO_SMALL" });
    return;
  }
  if (input.kind === "exchange" && (!input.exchangeRate || !Number.isFinite(input.exchangeRate))) {
    res.status(400).json({ error: "EXCHANGE_RATE_REQUIRED" });
    return;
  }

  const targetCurrency: ShopCurrency | null =
    input.kind === "exchange" ? (input.currency === "USD" ? "IQD" : "USD") : null;
  const targetAmount =
    input.kind === "exchange"
      ? cents(
          input.currency === "USD"
            ? amount * input.exchangeRate!
            : amount / input.exchangeRate!,
        )
      : null;
  if (targetAmount !== null && targetAmount <= 0) {
    res.status(400).json({ error: "CONVERTED_AMOUNT_TOO_SMALL" });
    return;
  }

  const result = await db.transaction(async (tx) => {
    await tx.execute(sql`SELECT pg_advisory_xact_lock(${currencyAccountLockId})`);
    const previousRows = await tx.select().from(currencyTransactionsTable);
    const balances = currencyBalances(previousRows);
    if (input.kind !== "deposit" && balances[input.currency] + 0.001 < amount) {
      return "INSUFFICIENT_CURRENCY_BALANCE";
    }

    const [row] = await tx
      .insert(currencyTransactionsTable)
      .values({
        kind: input.kind,
        currency: input.currency,
        amount: String(amount),
        targetCurrency,
        targetAmount: targetAmount === null ? null : String(targetAmount),
        exchangeRate:
          input.kind === "exchange" ? String(input.exchangeRate) : null,
        note: input.note ?? null,
      })
      .returning();
    return row;
  });

  if (typeof result === "string") {
    res.status(400).json({ error: result });
    return;
  }
  res.status(201).json(CreateCurrencyTransactionResponse.parse(currencyTransactionResponse(result)));
});

export default router;